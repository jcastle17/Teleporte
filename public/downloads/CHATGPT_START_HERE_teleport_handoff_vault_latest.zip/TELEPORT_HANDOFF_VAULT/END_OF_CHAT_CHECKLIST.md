# End-of-Chat Checklist

Before passing the vault to the next chat, complete this checklist.

## Required updates
- [ ] Add one new file in `SESSION_DELTAS/` for this chat.
- [ ] Update `01_CURRENT_STATE.md`.
- [ ] Update `06_PENDING_TASKS.md`.
- [ ] Update `07_NEXT_ACTION.md`.
- [ ] Add a new entry to `08_SESSION_LOG.md`.
- [ ] Update `KNOWN_UNKNOWNS.md` if anything remains uncertain.
- [ ] Update `SCREENSHOT_EXTRACT_LOG.md` if screenshots were used and mattered.
- [ ] Update `ATTACHMENT_INDEX.md` only if actual files/images/docs were intentionally preserved.
- [ ] Update `PACKET_AUDIT_LOG.md` if the vault structure changed.
- [ ] Update `VERSION_HISTORY.md` if a new structural version was created.

## Safety checks
- [ ] No API keys, tokens, passwords, secret values, private keys, or recovery codes were saved.
- [ ] Screenshots were not saved by default.
- [ ] Sensitive info was redacted from extracts.
- [ ] Unknowns were marked instead of guessed.
- [ ] Raw transcripts were not used as active instructions.
- [ ] Public links were not created without user approval.

## First action for next chat
- [ ] `07_NEXT_ACTION.md` clearly says what the next chat should do first.
- [ ] It says whether the next chat should use Light Load, Medium Load, Deep Mode, or Full Archive Mode.

## Final packaging
- [ ] Create/export the updated ZIP if the user wants a downloadable handoff.
- [ ] If using a remote vault, commit/push the updated files only after user approval when needed.
