# Redacted Secrets Inventory

This file records which secrets exist and where they live. It must never contain actual secret values.

## Rules
- Do not paste API keys, tokens, passwords, private keys, recovery codes, database credentials, or secret values into this file.
- Do not include revealing hints, partial token patterns, screenshots showing secrets, or terminal output containing secrets.
- Use `[VALUE INTENTIONALLY OMITTED]` for all secret values.

## Template

### Secret name
`[SECRET_NAME]`

Purpose:
[What this secret is used for]

Location:
[Cloudflare Pages secret / GitHub Actions secret / local `.env` / password manager / other secure location]

Environment:
[production / preview / development / unknown]

Value:
`[VALUE INTENTIONALLY OMITTED]`

Rotation status:
[unknown / active / should rotate / rotated on YYYY-MM-DD]

Notes:
[Do not include secret value]

---

## Known project secret placeholders

### GEMINI_API_KEY
Purpose: Allows the website/backend/coding workflow to call Gemini where configured.
Location: Cloudflare/GitHub secure secret storage if already set up.
Value: `[VALUE INTENTIONALLY OMITTED]`
Notes: Do not ask user to paste this into chat unless there is a specific secure secret-entry step.

### INGEST_AUTH_TOKEN
Purpose: Protects ingest/admin update routes.
Location: Cloudflare Pages secret storage if already set up.
Value: `[VALUE INTENTIONALLY OMITTED]`
Notes: The value should never be written in chat, repo files, README, screenshots, or prompt logs.
