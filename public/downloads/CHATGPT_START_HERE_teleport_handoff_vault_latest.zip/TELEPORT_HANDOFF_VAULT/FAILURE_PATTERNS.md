# Failure Patterns

Record repeated problems so future chats avoid them.

## Template

### Failure: [Title]
Date noticed: [YYYY-MM-DD]

What happened:
[Problem]

Do instead:
[Correction]

Why it matters:
[Reason]
