# Vault Retention Levels

## Purpose
This file defines what gets saved, what gets summarized, and what gets excluded.

## Level 0 — Do Not Save
Do not preserve the item in the vault.

Use for:
- temporary screenshots that only helped with navigation
- private notifications or unrelated screen clutter
- duplicate images
- accidental uploads
- visible secrets, tokens, passwords, or private codes
- account/billing pages unless a redacted note is necessary

Save instead: nothing, or a short redacted note if it affected the work.

## Level 1 — Extract Only
Save a redacted text extract, not the original file/image.

Use for most screenshots.

Save:
- what mattered
- what decision/action it affected
- visible error messages, if needed
- redacted UI state
- next action caused by the screenshot

Do not save:
- the original screenshot
- private clutter
- visible tokens or full private URLs

## Level 2 — Redacted Copy
Save a redacted copy only after removing sensitive details.

Use for:
- screenshots that need to preserve layout or visual context
- legal/document formatting examples
- UI evidence that matters later but contains private data

Redact before saving:
- names/addresses/phone numbers/emails unless necessary
- account IDs, secret values, links, dashboards
- private messages not directly needed

## Level 3 — Original Preserved
Save the original file only when the user clearly says it matters as an original.

Trigger phrases include:
- "save this screenshot"
- "preserve this image"
- "attach this"
- "keep the original"
- "this is evidence"
- "put the original in the vault"

Use for:
- legal/custody evidence the user specifically wants preserved
- final generated outputs
- source files that must remain editable
- screenshots needed for exact future comparison

## Default retention rule
If no retention level is specified, use Level 1 for screenshots and Level 0 for irrelevant private clutter.

## Storage rule
GitHub should store mostly text records. Large files should go to Drive/iCloud/R2 with only the index/link saved in GitHub.
