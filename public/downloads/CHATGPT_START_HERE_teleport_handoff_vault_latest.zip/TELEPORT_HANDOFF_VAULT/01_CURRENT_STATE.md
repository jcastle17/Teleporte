# Current State — Latest Official Checkpoint Installed

## Installed update
`00_LATEST_CHECKPOINT_READ_FIRST.md` has been replaced with the official main teleport checkpoint provided on 2026-05-23.

## Current primary project from latest checkpoint
**Box Elder Answers / T1 Civic Tracker**

## Current official status from checkpoint
The website/civic tracker is live on Cloudflare Pages at `https://t1-a2g.pages.dev/`. The AI civic tracker, Cloudflare Pages/Functions, D1, Gemini integration, `/api/status`, `/api/ingest`, and `/api/feed` are described as connected and functioning. The major blocker is no longer backend connection; the remaining work is visual review, small polish, and any tiny publisher/source-label refinement if still visible.

## Fresh verification target
Open the cache-busted homepage URL from the checkpoint first:
`https://t1-a2g.pages.dev/?v=1779561494`

Then visually review `/feed`, `/stratos`, `/water`, `/power`, `/community`, `/records`, and `/admin` before preparing any new coding mission.

## Important note
This checkpoint supersedes older side logs unless those logs are needed for extra detail. The side-chat log in `04_CHAT_LOG_INBOX/` remains useful context but does not override the main checkpoint.

---

# Current State

## Project name
Teleport Handoff Vault

## Main mission
Create a repeatable system where one chat can pass its exact history, working rules, current status, corrections, and next action to the next chat so the next chat feels like the previous chat came with the user.

## Current status
The vault template has been created. It is intended to be stored in remote storage such as a private GitHub repo, Cloudflare storage, Google Drive, iCloud Drive, or another controlled location.

## Active project / topic
[Fill in the current project name here]

## Where we left off
[Update this at the end of every chat]

## Next safest action
[Update this at the end of every chat]

## Important current files
- `00_READ_ME_FIRST.md`
- `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
- `01_CURRENT_STATE.md`
- `08_SESSION_LOG.md`
- `SESSION_DELTAS/`
- `10_RAW_TRANSCRIPT.md`

## Do not guess
If something is missing, mark it as unknown instead of inventing it.

## 2026-05-23 Update — Bootloader ZIP
The vault was upgraded so new chats have a clear, enforced-by-instruction boot sequence. It cannot auto-run, but the first-open file and AI_BOOTSTRAP.json tell the next chat exactly how to load the packet, orient itself, and update the vault at the end.


## Update — 2026-05-23: Screenshot-light vault policy

The vault now includes a screenshot retention policy. Future chats should not store every screenshot. They should extract useful information into `SCREENSHOT_EXTRACT_LOG.md`, redact sensitive details, and preserve original screenshots only when the user explicitly says to save them.

## Latest vault status update — 2026-05-23
The vault now includes the control-safety-load-mode expansion. Future chats should use Light Load by default, protect against prompt injection from old content, avoid saving screenshots by default, redact sensitive information, and run the end-of-chat checklist before passing the vault forward.


## Latest vault status update — 2026-05-23: Maintenance/Search/Archive Expansion
The vault now includes naming rules, tagging, a search guide, monthly archive plan, projects index, active-projects list, do-not-carry-forward rules, confidence levels, remote sync rules, and a test startup script. Future chats should use the light-load files first, search index/delta files before raw transcripts, and keep GitHub focused on text while heavy files live in Drive/iCloud/R2 or another controlled storage location.

## Skeleton update — one-link remote architecture

The vault is currently being strengthened as a skeleton, not yet a live database/storage system. The intended future remote setup is Cloudflare as the one-link boot page, GitHub as version-controlled source and release ZIP host, and Google Drive as private backup/heavy storage.

The skeleton now includes templates and rules for a future chat to understand a single pasted link without needing an extra command, subject to the limitation that a link cannot force every chat to browse or download automatically.
---

# v1.5 Inbox Log Addendum — 2026-05-23

Four new Markdown chat logs were installed into `04_CHAT_LOG_INBOX/` after the official v1.4 checkpoint:

- `chat-log-gemini-copilot-cloudflare-d1-activation-2026-05-23.md`
- `chat-log-website-improvement-suggestions-2026-05-23.md`
- `chat-log-website-redesign-reference-pass-2026-05-23.md`
- `chat-log-building-local-business-websites-2026-05-23.md`

## Important handling note

These are supporting logs, not a replacement checkpoint. The official current project state remains controlled by `00_LATEST_CHECKPOINT_READ_FIRST.md` unless the user requests a new checkpoint.

If the D1/cloud/backend status in older logs appears less complete than the checkpoint, treat the checkpoint as newer current truth and use the logs only for context/history.

## New side-project context added

The Lucky 75 Barber & Salon Parlour website appears as a separate local-business website project. It should not be mixed into the Box Elder Answers / T1 Civic Tracker work unless the user specifically asks about the local-business website workflow.
