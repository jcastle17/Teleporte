# Human Quick Start

This is the plain-English guide for using the Teleport Handoff Vault.

## Start a new chat
1. Give the new chat the vault ZIP or link.
2. Paste this instruction:

Open `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt` first and follow the boot sequence. Use Light Load unless I ask you to deep dig.

3. Wait for the chat to tell you:

- current mission
- where we left off
- active rules
- known blockers
- next safest action

## Normal continuation
Say:

Use Light Load and continue from `07_NEXT_ACTION.md`.

## When you need exact old details
Say:

Deep dig the vault for the exact place we talked about [topic]. Check transcript index, session deltas, and raw transcripts only as needed.

## When screenshots are involved
Default rule:

Do not save the screenshot. Save only a redacted extract of what mattered.

If you really want the original saved, say:

Save this screenshot as an original attachment.

## End of a chat
Say:

Update the Teleport Handoff Vault for the next chat. Add a session delta, update current state, pending tasks, next action, session log, known unknowns, and screenshot extract log if needed. Do not save secrets or original screenshots unless I explicitly asked.

## Simple memory rule
The vault carries the memory. The startup prompt tells the next chat how to load it. The session delta tells the following chat what changed.


## Quick test after upload
After uploading or linking the vault in a fresh chat, use `TEST_STARTUP_SCRIPT.md` to make sure the chat loads only the light files first and does not open raw transcripts unless needed.
