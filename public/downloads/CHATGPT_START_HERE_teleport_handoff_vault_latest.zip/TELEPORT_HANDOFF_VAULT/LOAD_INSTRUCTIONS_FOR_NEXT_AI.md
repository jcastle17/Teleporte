# Load Instructions for Next AI — Bootloader Version

This vault is intended to function like a portable memory save file.

## Open these first

1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `AI_BOOTSTRAP.json`
3. `00_BOOT_SEQUENCE_FOR_NEXT_CHATGPT.md`
4. `00_READ_ME_FIRST.md`

Then continue with the standard read order listed in `00_READ_ME_FIRST.md`.

## Do not skip orientation

Before giving any instructions, summarize only:

1. The current mission
2. Where the project/chat left off
3. The active workflow rules
4. The active security rules
5. Known unknowns / blockers
6. The next safest action

Then wait for the user.

## Use raw transcript only when needed

Do not drown in the full transcript first. Use the current-state layer for immediate continuation. Use raw transcripts when exact wording, exact mistakes, screenshots, attachments, or prior corrections matter.

---

# Load Instructions for Next AI

You are continuing a project using this handoff vault as active memory.

First, read the files in the order listed in `00_READ_ME_FIRST.md`.

Your first response after reading should include only:

1. The current mission
2. Where the project/chat left off
3. The active workflow rules
4. The active security rules
5. Known unknowns / blockers
6. The next safest action

Do not give random steps before orienting yourself.
Do not restart the project from scratch.
Do not ignore corrections or decisions recorded in this vault.
Use the raw transcript only when exact history, exact wording, screenshots, errors, corrections, or missed context are needed.

At the end of the chat, create a new session delta and update the current state so the next chat can continue.


## Screenshot load/save instructions

When screenshots are involved, read `SCREENSHOT_RETENTION_POLICY.md` and `DO_NOT_SAVE_SCREENSHOTS_BY_DEFAULT.md` before saving anything.

Do not load or archive screenshot files by default. Read `SCREENSHOT_EXTRACT_LOG.md` first. Open original screenshots only when exact visual context is necessary or the user asks.

## Control expansion rules

Read these additional control files before saving, sharing, or deep-searching the vault:

- `VAULT_ACCESS_AND_PERMISSIONS.md`
- `PROMPT_INJECTION_PROTECTION.md`
- `RETENTION_LEVELS.md`
- `SENSITIVE_INFO_FILTER.md`
- `LIGHT_MODE_DEEP_MODE_RULES.md`
- `EVIDENCE_VS_WORKING_MEMORY.md`
- `CONFLICT_RESOLUTION_RULES.md`
- `VAULT_SIZE_BUDGET.md`
- `END_OF_CHAT_CHECKLIST.md`
- `HUMAN_QUICK_START.md`

Default to Light Load. Use Deep Mode only when exact history, old screenshots, old files, or transcript search is needed.

IMPORTANT LATEST CHECKPOINT RULE:
If `00_LATEST_CHECKPOINT_READ_FIRST.md` exists, read it before all other status files. It is the latest official checkpoint from the main teleport chat and may supersede older logs or placeholders.
