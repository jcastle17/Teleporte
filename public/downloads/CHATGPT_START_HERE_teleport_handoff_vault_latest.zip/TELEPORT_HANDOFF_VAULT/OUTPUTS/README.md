# OUTPUTS

This folder is reserved for outputs. Follow vault retention and sensitive-info rules before adding files.
