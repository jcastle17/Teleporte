# Chat Log Inbox

Purpose: collect clean Markdown log entries from side chats or helper chats before they are merged into the official vault state.

## Rule

Incoming chat logs go here first. Do **not** let every side chat directly overwrite the official current-state files.

The main teleport chat or vault maintainer should review each inbox log, then decide whether it should update:

- `01_CURRENT_STATE.md`
- `06_PENDING_TASKS.md`
- `07_NEXT_ACTION.md`
- `00_LATEST_CHECKPOINT_READ_FIRST.md`

## Installed inbox logs

- `chat-log-gemini-coding-workflow-3-2026-05-23.md` — clean Markdown log. It reports that no coding/deployment work occurred in that chat yet and that the chat is waiting for the formal handoff.
- `chat-log-gemini-copilot-cloudflare-d1-activation-2026-05-23.md` — Cloudflare/Gemini/Copilot/D1 activation workflow log. Includes D1/civic-tracker setup history, security decisions, stop conditions, and notes that it wants state/tasks/next-action updates.
- `chat-log-website-improvement-suggestions-2026-05-23.md` — Website build/deploy recovery log. Covers Cloudflare Pages build fixes, RSS proxy, Updates page wiring, Gemini CLI setup, and safe-token handling.
- `chat-log-website-redesign-reference-pass-2026-05-23.md` — Box Elder Answers redesign/reference log. Captures cinematic/interactive redesign direction and reference websites/packages.
- `chat-log-building-local-business-websites-2026-05-23.md` — Lucky 75 Barber & Salon Parlour local-business website log. Captures separate side project direction, homepage/story/booking structure, visual rules, and screenshot digestion.

## v1.5 note

Four additional logs were installed after the official v1.4 checkpoint. They are useful supporting history, but they do **not** automatically override `00_LATEST_CHECKPOINT_READ_FIRST.md`.

If a log conflicts with the latest checkpoint, use the supersession rule: the latest checkpoint is the current official truth unless the user asks to create a newer checkpoint.

## Processing rule

After a log has been reviewed and reflected in official files, it may be copied or moved to `05_PROCESSED_CHAT_LOGS/`.

Never include secrets, tokens, passwords, API keys, private raw screenshots, or unnecessary personal information in inbox logs.
