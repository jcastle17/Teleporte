# Public / Private Split Rules

## Purpose

This vault may eventually be connected to GitHub, Cloudflare, and Google Drive. This file prevents private project memory from accidentally becoming public.

## Public-safe items

The following may be public if they contain no private identifiers:

- generic boot-page instructions
- read-order rules
- load-mode rules
- generic screenshot handling rules
- generic privacy/security rules
- generic vault naming rules
- public-safe manifest
- empty templates
- public loader ZIP

## Private-only items

Keep these private unless the user explicitly creates a sanitized public version:

- full raw transcripts
- screenshots
- exact custody/legal facts
- children's information
- phone numbers, emails, addresses, DOBs
- account/dashboard screenshots
- GitHub/Cloudflare/Google internal details
- private project plans that should not be public
- sensitive evidence logs
- secret inventory details beyond generic names/purposes

## Split-vault recommendation

Create two versions:

1. `PUBLIC_BOOT_LOADER/` — safe to host on Cloudflare.
2. `PRIVATE_WORKING_VAULT/` — full project memory, private only.

The public boot loader can say:

"This is a public-safe loader. Ask the user for the private working vault if deeper project memory is needed."

## Do not mix rule

Do not publish the full private vault as a public Cloudflare asset or public GitHub release unless it has been reviewed and sanitized.

## Safe default

When unsure, keep it private.
