# Version History

## v1.0
Created the first Teleport Handoff Vault template with core current-state, rules, decisions, corrections, session log, raw transcript, manifest, and startup prompt files.

## v1.1 Deep Backup Expansion
Added deeper recovery and backup files:
- `RESTORE_INSTRUCTIONS.md`
- `REDACTED_SECRETS_INVENTORY.md`
- `TOOL_ACCESS_MAP.md`
- `PROJECT_FILE_TREE.md`
- `EXACT_PROMPTS_USED.md`
- `BAD_PROMPTS_AND_BAD_OUTPUTS.md`
- `CHECKSUMS_AND_FILE_HASHES.md`
- `BACKUP_LOCATIONS.md`
- `TIMELINE_MASTER.md`
- `RECOVERY_SUMMARY_FOR_HUMAN.md`
- `REMOTE_SYNC_PLAN.md`
- `ACCESS_CONTROL_CHECKLIST.md`
- `EXPORT_AND_IMPORT_INSTRUCTIONS.md`
- `PACKET_AUDIT_LOG.md`

## Update rule
Every future vault ZIP should add a new version entry when structure, security rules, or workflow rules change.

## v1.4 — Bootloader Protocol Added — 2026-05-23
- Added first-open file, machine-readable AI_BOOTSTRAP.json, boot sequence, startup prompt copy file, and end-of-chat save protocol.
- Updated read order and source-of-truth rules.


## v1.2 — Read Order Lock

Added explicit read-order lock files so future chats can load the vault in the intended sequence every time.


## v1.2 — Screenshot Extract Policy Added — 2026-05-23

Added a default no-screenshot-retention rule. The vault now stores text-only screenshot extracts by default and preserves original screenshot files only when explicitly requested by the user.

## v1.4 — Control-Safety-Load-Mode Expansion
Added vault access/permissions, prompt-injection protection, retention levels, sensitive-info filter, light/deep load modes, evidence-vs-working-memory, conflict resolution, vault size budget, end-of-chat checklist, and human quick-start.


## v1.5 — Maintenance/Search/Archive Expansion — 2026-05-23
Added naming rules, tagging, search guide, monthly archive plan, projects index, active projects list, do-not-carry-forward rules, confidence levels, remote sync rules, and a startup test script. Updated boot/read-order/JSON files so future chats search indexes and session deltas before raw transcripts.

## 2026-05-23 — v1.2 One-Link Remote Architecture

Added Cloudflare boot-page template, one-link behavior rules, GitHub release ZIP guidance, Google Drive backup role, public/private split rules, and simpler-method comparison.

This version is still a skeleton. It is designed to work before any database/storage engine exists.

## v1.3 — Chat Log Inbox and Latest Checkpoint Chain — 2026-05-23

- Added `00_LATEST_CHECKPOINT_READ_FIRST.md` placeholder.
- Added `04_CHAT_LOG_INBOX/` and `05_PROCESSED_CHAT_LOGS/`.
- Installed the uploaded `chat-log-gemini-coding-workflow-3-2026-05-23.md` into the inbox.
- Added `CHAT_LOG_ENTRY_TEMPLATE.md` and `LATEST_CHECKPOINT_TEMPLATE.md`.
- Updated pending tasks, next action, session log, manifest, boot/read-order files, and checksums to recognize the checkpoint-and-inbox handoff chain.


## v1.4 — Official Latest Checkpoint Installed — 2026-05-23

- Replaced placeholder checkpoint with the official `00_LATEST_CHECKPOINT_READ_FIRST.md` uploaded by the user.
- Made Box Elder Answers / T1 Civic Tracker the current primary project context for the next chat.
- Updated the next action to visual review of the fresh live homepage and key routes before any further coding mission.
- Refreshed manifest, session log, bootstrap/read-order metadata, and checksums.


## v1.5 — Additional Chat Logs Installed — 2026-05-23
- Installed four new Markdown chat-log entries into `04_CHAT_LOG_INBOX/`.
- Added v1.5 addenda to current state, pending tasks, next action, manifest, active projects, projects index, session log, audit log, and latest checkpoint.
- Preserved the rule that the official latest checkpoint remains current truth unless the user creates a newer checkpoint.
- Added Lucky 75 Barber & Salon Parlour as a separate local-business side project.
- No secrets, tokens, passwords, API keys, private raw screenshots, or private credential values were added.
