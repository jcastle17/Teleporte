# Exact Prompts Used

Purpose: preserve prompts that worked well so future chats can reuse them instead of recreating them.

## Next chat startup prompt

```text
Read the uploaded Teleport Handoff Vault first.

Start with 00_READ_ME_FIRST.md and LOAD_INSTRUCTIONS_FOR_NEXT_AI.md.

Then read CURRENT_STATE, USER_STYLE_AND_RESPONSE_RULES, SECURITY_AND_PRIVACY_RULES, SOURCE_OF_TRUTH, DECISION_LEDGER, CORRECTION_LEDGER, PENDING_TASKS, NEXT_ACTION, latest SESSION_LOG entry, and the latest SESSION_DELTA.

Use RAW_TRANSCRIPT only when exact history or wording is needed.

Before giving steps, tell me:
1. the current mission,
2. where we left off,
3. the active rules,
4. known blockers,
5. the next safest action.

Then wait for my instruction.
```

## Vault update prompt

```text
Update the Teleport Handoff Vault for the next chat.

Create one new session delta in SESSION_DELTAS.

Update:
01_CURRENT_STATE.md
06_PENDING_TASKS.md
07_NEXT_ACTION.md
08_SESSION_LOG.md
KNOWN_UNKNOWNS.md if needed
ATTACHMENT_INDEX.md if files were added

Do not store API keys, tokens, passwords, private keys, secret values, or revealing hints.

Mark unknowns clearly instead of guessing.
```

## Gemini/Copilot mission prompt template

```text
You are working inside the project repo. Read the handoff files first. Do not expose secrets. Do not ask for repeated approval for safe read-only inspection. Batch read-only investigation. Make scoped edits needed to complete the mission. Build/test. Report at the end. Stop only for secrets/tokens, billing/paid services, Cloudflare dashboard-only settings, custom domain/DNS, destructive commands, force push, unresolved conflicts, or major ambiguous design decisions.

Mission:
[PASTE MISSION HERE]
```
