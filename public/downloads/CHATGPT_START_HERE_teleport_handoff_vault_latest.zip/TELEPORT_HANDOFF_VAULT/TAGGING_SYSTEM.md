# Tagging System

Purpose: make the vault searchable without forcing future chats to read everything.

## How to tag entries
Add simple lowercase tags to session deltas, pending tasks, screenshot extracts, and transcript index entries.

Example:

`Tags: #gemini #codespaces #security #next-action`

## Core tags
- `#handoff` — handoff vault structure, startup prompts, teleport workflow
- `#current-state` — current working status
- `#next-action` — immediate next step
- `#blocked` — blocked by missing access, quota, login, secrets, manual approval, etc.
- `#finished` — completed work
- `#needs-review` — user or future chat should verify
- `#unknown` — not confirmed

## Project/tool tags
- `#boxelderanswers`
- `#website`
- `#gemini`
- `#copilot`
- `#codespaces`
- `#github`
- `#cloudflare`
- `#d1`
- `#r2`
- `#worker`
- `#api`
- `#security`
- `#ipad`
- `#screenshots`
- `#legal`
- `#custody`
- `#documents`

## Rule
Tags are search helpers, not proof. If an exact fact matters, verify it in the relevant source file, transcript, or original record.
