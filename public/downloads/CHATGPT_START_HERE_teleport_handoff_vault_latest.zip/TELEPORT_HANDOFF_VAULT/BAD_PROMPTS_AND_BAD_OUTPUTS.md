# Bad Prompts and Bad Outputs

Purpose: preserve patterns that failed so future chats do not repeat them.

## Pattern: tiny-step coding babysitting
Problem: The assistant breaks a coding mission into many small approvals or explanations.
Correction: Use one end-to-end Gemini/Copilot mission prompt unless there is a true blocker.

## Pattern: assuming desktop shortcuts
Problem: The assistant gives Control/Command/Shift shortcuts without iPad alternatives.
Correction: Use iPad-friendly taps, one-line commands, paste-button/toolbar instructions, or ask Gemini to avoid desktop-only approval flows.

## Pattern: loose summary instead of teleport handoff
Problem: The assistant summarizes the chat but does not preserve exact history, corrections, files, and active rules.
Correction: Use raw transcript + current state + decision ledger + correction ledger + session delta.

## Pattern: exposing or requesting secrets in chat
Problem: The assistant asks for or records secret values.
Correction: Secret values stay in secure secret managers/Cloudflare/GitHub secret fields. The vault stores only names, locations, purposes, and `[VALUE INTENTIONALLY OMITTED]`.

## Pattern: guessing missing facts
Problem: The assistant fills in unknowns from assumption.
Correction: Mark unknowns clearly in `KNOWN_UNKNOWNS.md`.
