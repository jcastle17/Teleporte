# Attachment Index

Track files, screenshots, PDFs, images, docs, and outputs used in the project.

## Template

### Attachment: [File name]
Type: [image/PDF/doc/etc.]
Date added: [YYYY-MM-DD]
Location: [path]

Purpose:
[Why this file matters]

Related transcript section:
[Transcript section or session delta]


## Screenshot retention update — 2026-05-23

Screenshots are not automatically preserved in `ATTACHMENTS/IMAGES/`.

Default handling:
- Save a redacted text extract in `SCREENSHOT_EXTRACT_LOG.md`.
- Do not store the screenshot file unless the user explicitly asks.
- If a screenshot is preserved, list it here with reason and location.

Current preserved screenshots from this policy update:
- None.
