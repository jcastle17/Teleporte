# Source of Truth Rules

When files disagree, use this priority order:

1. `AI_BOOTSTRAP.json` and `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt` control loading/read order and first-response protocol.
2. `03_SECURITY_AND_PRIVACY_RULES.md` controls security and secret-handling rules.
3. `04_DECISION_LEDGER.md` controls settled project decisions unless a newer session delta explicitly updates the decision.
4. Latest dated file in `SESSION_DELTAS/` controls the newest session changes.
5. Latest entry in `08_SESSION_LOG.md` confirms the chronological update.
6. `01_CURRENT_STATE.md` controls the current working status.
7. `07_NEXT_ACTION.md` controls what to do next.
8. `10_RAW_TRANSCRIPT.md` and `RAW_TRANSCRIPTS/` control exact wording and exact historical facts.
9. If uncertainty remains, mark it in `KNOWN_UNKNOWNS.md` instead of guessing.

## Raw transcript rule

The raw transcript preserves exact history, but it should not be the first file read unless the user asks for exact transcript analysis. Start with the current-state layer, then use raw transcript for verification.

## Remote source-of-truth rule

For one-link handoff architecture, use this order:

1. `AI_LINK_ONLY_BOOT_PAGE.md` / live Cloudflare boot page controls link-only behavior.
2. GitHub release ZIP controls the latest packaged vault if the release asset is current.
3. Private GitHub repo controls editable text source if it is newer than the release ZIP.
4. Google Drive backup controls recovery only when GitHub/Cloudflare access breaks or the user says Drive has the newest copy.
5. Local uploaded ZIP controls the current conversation if the user just uploaded it and asked to modify it.

Cloudflare, GitHub, and Google Drive should not be treated as equal competing copies. Each has a role.
