# Screenshot Extract Template

Copy this template for each screenshot or screenshot group used in a chat.

---

## Screenshot Extract Entry

**Date/time:**  
[YYYY-MM-DD HH:MM if known]

**Session / topic:**  
[Short topic name]

**Screenshot group ID:**  
[Example: 2026-05-23-gemini-workflow-01]

**Original screenshot saved?:**  
No by default. Only "Yes" if user explicitly requested preservation.

**Original file location if saved:**  
[ATTACHMENTS/IMAGES/... or external link, otherwise "Not saved"]

**What screen/app/site/tool was shown:**  
[Example: GitHub Codespaces on iPad, Cloudflare dashboard, Gemini coding screen, Gmail draft, Photos metadata screen]

**Useful visible information extracted:**  
- [Fact/status/error/button/setting shown]
- [Fact/status/error/button/setting shown]
- [Fact/status/error/button/setting shown]

**Decision or action caused by screenshot:**  
[What changed because of the screenshot]

**Sensitive/private information omitted:**  
- [Example: private URL omitted]
- [Example: account email omitted]
- [Example: token/secret value omitted]
- [Example: unrelated personal notification omitted]

**Does future chat need original image?**  
No by default.  
Use "Yes" only if exact visual layout, evidence preservation, or image editing/review is required.

**Next action:**  
[What the next chat should do with this extracted information]

---
