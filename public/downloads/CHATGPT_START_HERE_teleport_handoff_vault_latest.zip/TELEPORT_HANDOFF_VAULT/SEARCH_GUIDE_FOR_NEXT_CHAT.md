# Search Guide for the Next Chat

Purpose: help a future chat find the right information without reading the whole archive.

## Default search path
1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
3. `01_CURRENT_STATE.md`
4. `ACTIVE_PROJECTS.md`
5. `07_NEXT_ACTION.md`
6. Latest file in `SESSION_DELTAS/`
7. `08_SESSION_LOG.md`
8. `KNOWN_UNKNOWNS.md`
9. `04_DECISION_LEDGER.md`
10. `05_CORRECTION_LEDGER.md`
11. `09_RAW_TRANSCRIPT_INDEX.md`
12. Relevant raw transcript only if exact wording/history is needed
13. `ATTACHMENT_INDEX.md` only if files/images/PDFs/screenshots matter

## Light search
Use for normal continuation. Read only the boot/current-state/rules/latest-delta files.

## Deep search
Use when the user asks to recover exact wording, locate a specific past issue, verify a correction, or find where something happened.

## Full archive search
Use only when the user explicitly asks to search/read everything or the project is badly confused.

## Never assume
If the vault does not contain proof of a fact, mark it as unknown instead of guessing.

## Screenshot search rule
Search screenshot extracts first. Open preserved original screenshots only if the user explicitly preserved them or exact visual proof is required.
