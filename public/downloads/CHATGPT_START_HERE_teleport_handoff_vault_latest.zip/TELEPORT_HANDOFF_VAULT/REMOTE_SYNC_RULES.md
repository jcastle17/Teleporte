# Remote Sync Rules

Purpose: control how the vault is stored and synced to GitHub, Google Drive, iCloud, Cloudflare R2, or other remote storage.

## Recommended storage split
- GitHub private repo: lightweight text brain files, rules, session deltas, indexes, prompts.
- Drive/iCloud/R2: heavy attachments, screenshots only when explicitly preserved, PDFs, videos, ZIP backups.
- ChatGPT upload: use ZIP or selected files when remote access is not available.

## Privacy rules
- Keep the vault private by default.
- Do not make GitHub public.
- Do not create public Drive/iCloud/R2 links unless the user explicitly approves.
- Do not store or sync secret values.
- Do not paste tokens, passwords, API keys, private keys, or recovery codes into prompts, commits, README files, or transcript archives.

## Update workflow
1. Work in chat.
2. Extract useful screenshot info without saving screenshots by default.
3. Add a session delta.
4. Update current state, pending tasks, next action, known unknowns, and session log.
5. Update indexes if files/transcripts were added.
6. Sync/push/upload only after checking sensitive info filters.

## Conflict rule
Newest remote vault does not automatically mean most correct. Use `CONFLICT_RESOLUTION_RULES.md` and verify if multiple copies exist.

## One-link remote source roles

Cloudflare: front door / boot page / public-safe loader.

GitHub: version-controlled source, release ZIPs, changelog, manifest, and templates.

Google Drive: private backup, emergency restore, and heavy files that should not live in a public loader.

Do not upload secrets or raw private screenshots into any public layer.

If the user asks for the easiest system, use Google Drive only. If the user asks for the best simplified system, use Cloudflare + GitHub only. If the user asks for the best balanced system, use Cloudflare + GitHub + Google Drive.
