# Sensitive Information Filter

## Purpose
This file tells future chats what must be removed, redacted, or omitted before saving notes, extracts, prompts, or handoff updates.

## Never save actual secret values
Do not save:

- API keys
- tokens
- passwords
- private keys
- recovery codes
- session cookies
- database credentials
- OAuth secrets
- verification codes
- full secret-bearing URLs
- revealing hints or patterns that could help recreate a secret

Use placeholders instead:

`[secret exists — value intentionally omitted]`

## Redact from screenshots and transcripts before saving extracts
Redact or omit:

- full emails unless needed
- phone numbers unless needed
- home/work addresses unless needed
- children's private identifying details unless directly relevant and user-requested
- DOBs unless needed for legal form context
- legal case numbers unless needed
- account IDs, dashboard IDs, customer IDs, billing info
- full URLs containing private tokens, auth parameters, or dashboard paths
- private notifications, message previews, inbox contents, unrelated tabs

## Legal/custody caution
The vault is not the official evidence archive. When legal/custody information is relevant, store only the working note needed for continuation unless the user specifically asks to preserve the original.

## Website/security caution
For Cloudflare, GitHub, Gemini, Google, Meta, Namecheap, email, and API workflows:

- record the setting name and secure storage location
- never record the secret value
- never paste secrets into Gemini/Copilot prompts
- never expose tokens in repo files, README files, screenshots, or handoff notes

## Safe wording examples
Good:
`Cloudflare Pages secret GEMINI_API_KEY exists in production environment. Value intentionally omitted.`

Bad:
`Cloudflare Pages secret GEMINI_API_KEY = abc123...`

Good:
`Screenshot showed a Codespaces terminal error. Private URL and account details omitted.`

Bad:
`Screenshot showed full dashboard URL, account email, and token-bearing link.`
