# Projects Index

Purpose: list the major workflows that may appear in this vault so future chats know what they are looking at.

## Active or recurring project areas

### Teleport Handoff Vault
Portable chat-continuation system. Includes bootloader, read order, rules, session deltas, screenshot-extract policy, and remote-vault plan.

### Box Elder Answers / Website Project
Public information/community-support website around Box Elder County / Project Stratos transparency. Includes Cloudflare Pages, GitHub, D1/API/feed/admin ideas, Gemini API integration, civic tracker/news-watch work, and public education pages.

### Gemini / Codespaces / Copilot Workflow
Coding workflow where ChatGPT prepares prompts, Gemini/Copilot performs repo work, and the user works mostly from iPad. Rules emphasize end-to-end mission prompts, iPad-friendly instructions, and stopping only for true blockers.

### Cloudflare / GitHub / Security Workflow
Hosting, deployment, secrets, D1/R2/Workers/Pages, API routes, and security controls. Secrets must never be stored in chat, repo files, or the vault.


### Local Business Website Builds
Separate website-building workflow for local businesses, including the Lucky 75 Barber & Salon Parlour redesign. Keep this separate from the Box Elder Answers civic project unless the user explicitly switches projects.

### Legal / Custody / Documents Workflow
Document drafting, summaries, strategy reports, custody/child-support materials, and records. Vault notes are not official evidence unless the original record is separately preserved.

### Screenshot / Visual Troubleshooting Workflow
Screenshots are temporary visual context by default. Store redacted extracts, not every image.

## Rule
Use `ACTIVE_PROJECTS.md` to see what is currently alive. This file is the broad map; it is not automatically current status.
