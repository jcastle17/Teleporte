# Session Delta — Screenshot Extract Policy Added

**Date:** 2026-05-23  
**Topic:** Added screenshot-light storage rules to Teleport Handoff Vault

## What changed

The vault now has a policy that prevents it from saving every screenshot by default.

## Files added

- `SCREENSHOT_RETENTION_POLICY.md`
- `DO_NOT_SAVE_SCREENSHOTS_BY_DEFAULT.md`
- `SCREENSHOT_EXTRACT_TEMPLATE.md`
- `SCREENSHOT_EXTRACT_LOG.md`

## Files updated

- `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
- `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
- `000_READ_ORDER_LOCK.json`
- `AI_BOOTSTRAP.json`
- `00_BOOT_SEQUENCE_FOR_NEXT_CHATGPT.md`
- `00_READ_ME_FIRST.md`
- `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
- `11_NEXT_CHAT_STARTUP_PROMPT.txt`
- `NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt`
- `END_OF_CHAT_SAVE_PROTOCOL.md`
- `ATTACHMENT_INDEX.md`
- `12_MANIFEST.md`
- `QUALITY_CHECKLIST.md`
- `VERSION_HISTORY.md`
- `PACKET_AUDIT_LOG.md`

## New standing rule

Screenshots are temporary visual context by default. The vault saves a redacted text extract, not the screenshot image file, unless the user explicitly says to save, preserve, attach, or keep the original image.

## Next chat instruction

When screenshots are involved, read `SCREENSHOT_RETENTION_POLICY.md` and use `SCREENSHOT_EXTRACT_TEMPLATE.md`. Do not open or save screenshot files unless necessary.
