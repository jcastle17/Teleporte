# Session Delta — 2026-05-23 — Maintenance/Search/Archive System Added

## What changed
Added maintenance and scaling files so the Teleport Handoff Vault stays organized as it grows.

## Files added
- `VAULT_NAMING_RULES.md`
- `TAGGING_SYSTEM.md`
- `SEARCH_GUIDE_FOR_NEXT_CHAT.md`
- `MONTHLY_ARCHIVE_PLAN.md`
- `PROJECTS_INDEX.md`
- `ACTIVE_PROJECTS.md`
- `DO_NOT_CARRY_FORWARD.md`
- `CONFIDENCE_LEVELS.md`
- `REMOTE_SYNC_RULES.md`
- `TEST_STARTUP_SCRIPT.md`

## Read-order updates
The bootloader, master read order, JSON read-order lock, AI bootstrap, manifest, session log, current state, version history, checksums, and audit log were updated.

## Rule added
Future chats should use Light Load by default, use search/index files before raw transcripts, preserve screenshots only when explicitly told, and use confidence labels when something is not confirmed.

## Next action
Store the vault in a private remote location, preferably an unzipped private GitHub repo for text files plus Drive/iCloud/R2 for heavy files, then test the vault in a fresh chat using `TEST_STARTUP_SCRIPT.md`.
