# Session Delta — Read Order Lock Added

## What changed

The vault was updated so the next chat has an explicit read-order lock.

## Files added

- `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
- `000_READ_ORDER_LOCK.json`

## Files updated

- `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
- `AI_BOOTSTRAP.json`
- `12_MANIFEST.md`

## Purpose

To make the ZIP easier for future chats to load correctly every time by placing the read order in both human-readable and machine-readable files.

## Important limit

The ZIP still cannot automatically execute or force ChatGPT to read itself. The user must upload the ZIP and tell the chat to open the first file or follow the boot sequence.
