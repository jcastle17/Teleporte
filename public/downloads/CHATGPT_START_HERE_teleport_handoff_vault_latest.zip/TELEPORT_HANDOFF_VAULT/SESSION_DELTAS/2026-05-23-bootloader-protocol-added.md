# Session Delta — 2026-05-23 — Bootloader Protocol Added

## What changed

The user wanted the ZIP to be "programmed" so every new ChatGPT chat knows how to read it correctly every time.

A true ZIP cannot force ChatGPT to auto-run code or automatically read itself. To get as close as safely possible, the vault was upgraded with bootloader-style instruction files.

## Files added

- `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
- `AI_BOOTSTRAP.json`
- `00_BOOT_SEQUENCE_FOR_NEXT_CHATGPT.md`
- `NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt`
- `END_OF_CHAT_SAVE_PROTOCOL.md`

## Files updated

- `00_READ_ME_FIRST.md`
- `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
- `SOURCE_OF_TRUTH.md`
- `12_MANIFEST.md`

## New rule

Whenever this ZIP is uploaded into a new chat, the user should paste the startup prompt from `NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt`, or say:

"Open !!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt first and follow the boot sequence."

## Reality limit

The packet can strongly instruct the next chat, but the user still has to upload the ZIP or give access to the remote vault. ChatGPT does not automatically know about the file unless it is provided.
