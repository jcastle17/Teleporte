# Session Delta Template

## Session
Date: [YYYY-MM-DD]
Title: [Short title]

## What happened
- [What happened in this chat]

## What changed
- [Files/rules/decisions/status changed]

## Decisions made
- [Decision]

## Corrections added
- [Correction]

## Files created/updated
- [File]

## Known unknowns
- [Unknown]

## Next action for the next chat
- [Next action]

## Security notes
- No secrets stored.
- [Any relevant security note]
