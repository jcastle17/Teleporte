# Monthly Archive Plan

Purpose: keep the vault light over time.

## At the end of each month
1. Keep the active top-level files current:
   - `01_CURRENT_STATE.md`
   - `06_PENDING_TASKS.md`
   - `07_NEXT_ACTION.md`
   - `08_SESSION_LOG.md`
   - `KNOWN_UNKNOWNS.md`
2. Move older raw transcripts into:
   - `ARCHIVE/YYYY-MM/RAW_TRANSCRIPTS/`
3. Move older session deltas into:
   - `ARCHIVE/YYYY-MM/SESSION_DELTAS/`
4. Keep indexes updated:
   - `09_RAW_TRANSCRIPT_INDEX.md`
   - `ATTACHMENT_INDEX.md`
   - `PROJECTS_INDEX.md`
5. Do not delete evidence, important extracts, or original files the user explicitly preserved.
6. Keep GitHub mostly text. Move heavy media to Drive, iCloud, Cloudflare R2, or another controlled storage location.

## Compression rule
For inactive months, create a ZIP backup and store it outside the active GitHub repo if it contains large files.

## Safety rule
Do not archive secrets, tokens, passwords, private keys, recovery codes, or secret values. Use `REDACTED_SECRETS_INVENTORY.md` only.
