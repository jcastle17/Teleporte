# Remote Sync Plan

Purpose: outline how this vault can later become a real remote memory engine.

## Phase 1 — Manual private GitHub vault
- Store this folder in a private GitHub repo.
- At the end of each chat, update files and commit changes.
- Use GitHub version history as the backup engine.

## Phase 2 — ZIP export backups
- Generate dated ZIPs after major sessions.
- Save one copy in GitHub releases or `OUTPUTS/zip_exports/`.
- Save one copy in iCloud/Google Drive/local Files.

## Phase 3 — Cloudflare storage layer
Potential future setup:
- Cloudflare D1 for session metadata and current state.
- Cloudflare R2 for large raw transcripts, screenshots, PDFs, and ZIPs.
- Cloudflare Worker API for authenticated read/write.
- Admin page for reviewing and exporting handoff packets.

## Phase 4 — MCP/custom tool layer
Potential future setup:
- A private tool that lets ChatGPT load the current vault and write a new session delta.
- Require explicit user permission for writes.
- Never return secret values to the chat.

## Safety rule
Do not use random browser extensions to scrape live chat and auto-upload content. Use intentional exports and controlled write actions.

## Phase 0.5 — One-link boot page

Before building a database or storage engine, publish a simple Cloudflare Pages boot page using `AI_BOOT_PAGE_HTML_TEMPLATE.html`.

The boot page should link to the latest GitHub release ZIP and optionally a private/backup Google Drive copy.

Recommended flow:

`Cloudflare boot page -> GitHub latest release ZIP -> vault read order -> light load -> current state / pending tasks / next action`

Do not build Cloudflare R2, D1, Workers, or authenticated write APIs until the one-link skeleton passes `LINK_ONLY_BOOT_TEST.md`.
