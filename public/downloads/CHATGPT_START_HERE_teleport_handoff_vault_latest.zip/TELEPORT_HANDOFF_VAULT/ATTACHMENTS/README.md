# ATTACHMENTS

This folder is reserved for attachments. Follow vault retention and sensitive-info rules before adding files.
