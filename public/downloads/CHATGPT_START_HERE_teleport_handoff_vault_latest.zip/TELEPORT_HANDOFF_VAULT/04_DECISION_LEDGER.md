# Decision Ledger

Record decisions that should remain settled unless the user changes them.

## Decision template

### Decision: [Title]
Date: [YYYY-MM-DD]

What was decided:
[Decision]

Why it matters:
[Reason]

Status:
Active / Replaced / Deprecated

---

### Decision: Use a two-layer handoff system
Date: [Fill in]

What was decided:
Use both a raw transcript archive and an active working-memory layer.

Why it matters:
The raw transcript preserves exact history, while current-state files let the next chat continue quickly without drowning in the full transcript.

Status:
Active
