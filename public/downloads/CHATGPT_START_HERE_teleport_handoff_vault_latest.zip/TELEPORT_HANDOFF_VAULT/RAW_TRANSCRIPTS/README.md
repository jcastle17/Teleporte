# RAW_TRANSCRIPTS

This folder is reserved for raw transcripts. Follow vault retention and sensitive-info rules before adding files.
