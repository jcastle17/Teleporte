# Do Not Save Screenshots By Default

## Standing rule

Screenshots are temporary unless the user explicitly marks them for preservation.

The vault should **not** automatically save screenshot files to `ATTACHMENTS/IMAGES/`.

Instead, create a redacted text extract in:

`SCREENSHOT_EXTRACT_LOG.md`

## Exact instruction for future chats

When the user uploads screenshots:

1. Look at the screenshot.
2. Use it to help the user.
3. Extract only useful facts, errors, decisions, visible UI state, and next actions.
4. Redact private or sensitive details.
5. Add a text entry to `SCREENSHOT_EXTRACT_LOG.md` if the screenshot affects the project/handoff.
6. Do not save the original screenshot unless the user clearly says to save it.

## Trigger phrases that allow saving the screenshot

Only save the screenshot if the user says something like:

- "save this screenshot"
- "preserve this screenshot"
- "attach this image"
- "this is evidence"
- "keep the original"
- "add this screenshot to the vault"

## Default answer when uncertain

If unsure whether to preserve the original image, do not save it. Save only a redacted text extract.

Generated: 2026-05-23
