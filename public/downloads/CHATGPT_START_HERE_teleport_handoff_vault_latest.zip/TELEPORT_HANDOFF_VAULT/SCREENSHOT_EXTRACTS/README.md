# SCREENSHOT_EXTRACTS

This folder is reserved for screenshot extracts. Follow vault retention and sensitive-info rules before adding files.
