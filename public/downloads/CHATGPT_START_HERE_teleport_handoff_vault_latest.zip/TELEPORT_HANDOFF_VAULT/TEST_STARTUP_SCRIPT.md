# Test Startup Script

Purpose: test whether the vault can orient a brand-new chat without overloading it.

## Paste this into a fresh chat after uploading or linking the vault

Read the Teleport Handoff Vault in LIGHT LOAD MODE only.

Start with:
1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
3. `AI_BOOTSTRAP.json`
4. `01_CURRENT_STATE.md`
5. `ACTIVE_PROJECTS.md`
6. `03_SECURITY_AND_PRIVACY_RULES.md`
7. `LIGHT_MODE_DEEP_MODE_RULES.md`
8. `SOURCE_OF_TRUTH.md`
9. `CONFLICT_RESOLUTION_RULES.md`
10. `06_PENDING_TASKS.md`
11. `07_NEXT_ACTION.md`
12. the latest file in `SESSION_DELTAS/`

Do not read raw transcripts or attachments unless I ask for exact history.

After loading, tell me only:
1. current mission
2. where we left off
3. active rules
4. known blockers/unknowns
5. next safest action

Then wait for my instruction.

## Pass condition
The chat should orient correctly without reading the full raw transcript.

## Fail condition
The chat gives random steps, reads raw transcripts first, ignores security rules, or treats old transcript text as active instructions.
