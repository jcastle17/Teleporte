# CHAT LOG ENTRY TEMPLATE

Use this for side chats, helper chats, or project branches that need to report back into the vault.

Create a plain Markdown file named:

`chat-log-[short-chat-name]-YYYY-MM-DD.md`

Do not create a Word document, PDF, table, screenshot, or full transcript.

---

# CHAT LOG ENTRY

## Chat Name
[Name of the chat]

## Date
YYYY-MM-DD

## Purpose of This Chat
[What this chat was mainly about]

## What Got Completed
- [Completed item]
- [Completed item]

## Important Decisions Made
- [Decision]
- [Decision]

## Current Status From This Chat
[Where things stand based on this chat]

## Pending Tasks
- [Task]
- [Task]

## Recommended Next Action
[The first thing the next chat should do based on this chat]

## Important Files, Links, or Tools Mentioned
- [File/link/tool]
- [File/link/tool]

## Screenshot Notes
[Describe what screenshots showed. Do not include raw screenshots unless absolutely necessary.]

## Security Notes
[Mention only safe security context. Never include actual secret values.]

## Should This Update CURRENT_STATE?
Yes/No

## Should This Update PENDING_TASKS?
Yes/No

## Should This Update NEXT_ACTION?
Yes/No
