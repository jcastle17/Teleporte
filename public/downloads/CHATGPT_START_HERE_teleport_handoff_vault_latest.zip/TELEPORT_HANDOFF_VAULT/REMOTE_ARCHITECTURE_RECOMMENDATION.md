# Remote Architecture Recommendation

## Best balanced setup

Use:

- Cloudflare Pages as the one public boot link
- GitHub as the controlled source and release history
- Google Drive as private backup/heavy storage

This is the best balance of one-link usability, version history, recoverability, and privacy control.

## Source roles

### Cloudflare

Role: front door.

Cloudflare should host only the boot page and safe public loader files. It should not expose private raw transcripts, secrets, screenshots, custody/legal details, dashboard screenshots, API tokens, or full private archives.

### GitHub

Role: version-controlled vault source.

GitHub should hold the text-based vault and release ZIPs. Keep it private unless the vault is sanitized. GitHub history is useful because it shows how the vault changed over time.

### Google Drive

Role: backup and heavy-file storage.

Google Drive should hold large or sensitive files that should not live in the public front-door layer. Use restricted sharing by default.

## Public vs private split

### Public/safe layer

Can be hosted on Cloudflare:

- boot page
- public instructions
- generic manifest
- non-sensitive read order
- public version number
- public-safe ZIP only if fully sanitized

### Private layer

Should remain in private GitHub/Drive/local storage:

- raw transcripts
- screenshots
- legal/custody details
- account dashboards
- private IDs
- unreleased project notes
- secret inventory with secure-location hints
- anything involving children, addresses, phone numbers, emails, or case details

## Two-vault model

For long-term safety, use two vaults:

1. Public loader vault: tiny, safe, public, Cloudflare-hosted.
2. Private working vault: full project memory, private GitHub/Drive/local storage.

The public loader tells the AI what to do and where the private vault should be loaded from when the user provides access.

## Recommended version names

- `teleport-loader-public-v1.zip`
- `CHATGPT_START_HERE_teleport_handoff_vault_latest.zip`
- `teleport_handoff_vault_YYYY-MM-DD_v###.zip`
- `teleport_handoff_vault_private_working_copy.zip`

## Security posture

Default to private.

Public only means "safe to show strangers." It does not mean "useful for the full project."

Never store actual secret values in any vault.

Never put raw private screenshots in a public GitHub repo, public Cloudflare page, or public Drive link.

## Recommended future upgrade

If the project becomes more serious, use Cloudflare R2 for large files and a Cloudflare Worker with authentication for controlled read/write. That is more advanced than the current skeleton and should not be built until the basic one-link boot system is proven.
