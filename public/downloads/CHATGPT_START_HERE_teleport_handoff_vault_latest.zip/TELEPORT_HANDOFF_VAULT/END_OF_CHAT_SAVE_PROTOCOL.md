# End-of-Chat Save Protocol

Before this chat is passed to another chat, update the vault like this:

## 1. Update current working files

- `01_CURRENT_STATE.md` — current status after this chat
- `06_PENDING_TASKS.md` — remaining tasks
- `07_NEXT_ACTION.md` — exact next safest action
- `KNOWN_UNKNOWNS.md` — anything unclear or unverified

## 2. Append logs

- Add a new entry to `08_SESSION_LOG.md`
- Add one new file to `SESSION_DELTAS/` named like:
  `YYYY-MM-DD-session-short-topic.md`

## 3. Preserve exact history

When available, append exact visible conversation text to:
- `10_RAW_TRANSCRIPT.md`, or
- a dated file in `RAW_TRANSCRIPTS/`

Do not rewrite old raw transcript sections unless fixing formatting errors.

## 4. Track screenshots without saving originals

If screenshots were used:
- Do not save the screenshot files by default.
- Add useful, redacted facts to `SCREENSHOT_EXTRACT_LOG.md`.
- Use `SCREENSHOT_EXTRACT_TEMPLATE.md` for the entry.
- Save original screenshots in `ATTACHMENTS/IMAGES/` only if the user explicitly requested preservation.

## 5. Track files

If images, PDFs, docs, screenshots, ZIPs, outputs, or generated files were used, update:
- `ATTACHMENT_INDEX.md`
- `12_MANIFEST.md` if the vault structure changed

## 6. Security check

Before exporting:
- Confirm no API keys, tokens, passwords, secret values, private keys, or revealing hints are stored.
- Use placeholders like `[secret exists in Cloudflare Pages environment variables; value omitted]`.
- Do not include private credential screenshots.

## 7. Final response to user

Give the updated ZIP link and briefly say what changed.
