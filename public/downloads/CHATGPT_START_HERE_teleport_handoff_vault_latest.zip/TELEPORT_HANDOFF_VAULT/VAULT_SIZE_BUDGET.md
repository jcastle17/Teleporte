# Vault Size Budget

## Purpose
This file keeps the vault fast, cheap, and easy for future chats to load.

## Storage split
GitHub/private repo should store:

- markdown/text handoff files
- session deltas
- indexes
- redacted extracts
- prompts
- checklists
- small JSON files

Drive/iCloud/Cloudflare R2 should store:

- large screenshots
- PDFs
- videos
- full ZIP exports
- image libraries
- large raw transcripts
- original evidence files when appropriate

## Screenshot rule
Screenshots should not be saved by default. Use text extracts.

## Suggested size targets
For the GitHub text vault:

- ideal: under 50 MB
- acceptable: under 250 MB
- review/cleanup needed: over 500 MB
- avoid: multiple GB in GitHub

For screenshots/files:

- store outside GitHub unless explicitly needed
- group by date/project
- index them with filenames and descriptions
- do not make public links by default

## Monthly cleanup rule
Periodically archive old raw transcripts and large files into monthly ZIPs outside the main repo.

Example:

`ARCHIVE/2026-05-raw-transcripts.zip`

## Load-size rule
The next chat should load text brain files first. It should not load every attachment or raw transcript unless the user asks for deep search.
