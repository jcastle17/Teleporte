# Vault Access and Permissions

## Purpose
This file controls who should have access to the Teleport Handoff Vault and how it should be shared.

## Default access rule
The vault should remain private by default.

Do not make the vault public unless the user explicitly approves that specific action.

## GitHub rule
If the vault is stored in GitHub, the repository should be private unless the user explicitly says otherwise.

Do not upload sensitive legal records, private screenshots, children's information, addresses, tokens, API keys, passwords, or account dashboards into a public repo.

## Cloud / Drive rule
If the vault is stored in Google Drive, iCloud, Dropbox, Cloudflare R2, or other cloud storage:

- Use restricted/private sharing by default.
- Do not create public links by default.
- Do not make a folder "anyone with the link can view" unless the user explicitly approves.
- Prefer sharing only the specific lightweight loader files when possible.

## Third-party tool rule
Do not send raw transcripts, screenshots, attachments, legal records, custody records, or private dashboard screenshots to Gemini, Copilot, contractors, support staff, or other tools unless the user specifically instructs that it is necessary.

## Minimum disclosure rule
Share the smallest amount of vault content needed for the task.

Examples:
- For normal continuation: share/load current state, next action, rules, and latest delta.
- For exact wording: load the relevant raw transcript section only.
- For file/screenshot evidence: load only the specific file/extract needed.

## Private-data categories to protect
Treat the following as protected by default:

- API keys, tokens, secret values, passwords, private keys, recovery codes
- Cloudflare, GitHub, Google, Apple, Meta, or email account details
- private URLs, dashboard URLs, internal IDs, repo settings, billing/account pages
- phone numbers, email addresses, physical addresses, DOBs, children’s private details
- legal/custody/child-support details unless directly needed for the user's task
- screenshots showing private notifications, messages, account pages, inboxes, or dashboards

## User override
The user's latest direct instruction controls unless it would expose secrets, create a security risk, or violate safety/privacy rules.

## One-link public boot exception

A small Cloudflare boot page may be public if it contains only safe loader instructions and no private vault contents.

The public boot page may contain:

- generic AI handoff instructions
- read-first filename
- latest safe ZIP link
- safe manifest link
- security rules
- screenshot extraction policy
- prompt-injection warning

The public boot page must not contain:

- secret values or hints
- raw transcripts
- private screenshots
- legal/custody/private facts
- addresses, phone numbers, DOBs, account dashboards, or child-related private details

If a full private vault must be loaded, the user should provide the private ZIP or restricted link directly in the new chat.
