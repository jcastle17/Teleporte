# Boot Sequence for Next ChatGPT

This file turns the handoff packet into a repeatable loading process.

## What the next chat must do

1. Open `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`.
2. Open `AI_BOOTSTRAP.json` for the machine-readable read order.
3. Read the core handoff files in order.
4. Use `CURRENT_STATE`, `NEXT_ACTION`, latest `SESSION_LOG`, and latest `SESSION_DELTA` to pick up immediately.
5. Use raw transcripts only when exact wording or deeper history is needed.
6. Before giving procedural steps, produce the required orientation:
   - current mission
   - where we left off
   - active workflow rules
   - active security rules
   - blockers / unknowns
   - next safest action
7. Then wait for the user.

## What the next chat must not do

- Do not restart from scratch.
- Do not ignore correction ledger rules.
- Do not ask the user to repeat information already in the vault.
- Do not expose or request secret values unless the user is in a secure secret-entry step.
- Do not treat raw transcripts as the first thing to read unless the user specifically asks for exact transcript analysis.

## What to update before the chat ends

- `01_CURRENT_STATE.md`
- `06_PENDING_TASKS.md`
- `07_NEXT_ACTION.md`
- `08_SESSION_LOG.md`
- Add one new `SESSION_DELTAS/` file
- Update `KNOWN_UNKNOWNS.md` if needed
- Update `ATTACHMENT_INDEX.md` if files/images/docs were used
- Append raw visible transcript when available


## Screenshot extraction rule added 2026-05-23

Before saving any screenshot into the vault, check `SCREENSHOT_RETENTION_POLICY.md`.

Default behavior:
- Do not save screenshot image files.
- Save redacted text extracts in `SCREENSHOT_EXTRACT_LOG.md`.
- Use `SCREENSHOT_EXTRACT_TEMPLATE.md`.
- Preserve the original screenshot only when the user explicitly says to save/attach/preserve/keep it.

IMPORTANT LATEST CHECKPOINT RULE:
If `00_LATEST_CHECKPOINT_READ_FIRST.md` exists, read it before all other status files. It is the latest official checkpoint from the main teleport chat and may supersede older logs or placeholders.
