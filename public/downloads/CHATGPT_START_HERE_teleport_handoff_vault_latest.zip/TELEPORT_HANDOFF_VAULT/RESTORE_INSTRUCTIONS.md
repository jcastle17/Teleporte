# Restore Instructions

Purpose: rebuild or continue the Teleport Handoff Vault if a chat, ZIP, repo, or storage location becomes incomplete.

## Restore order
1. Open `00_READ_ME_FIRST.md`.
2. Open `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`.
3. Open `01_CURRENT_STATE.md`.
4. Open `SOURCE_OF_TRUTH.md`.
5. Open `03_SECURITY_AND_PRIVACY_RULES.md`.
6. Open `04_DECISION_LEDGER.md`.
7. Open `05_CORRECTION_LEDGER.md`.
8. Open `06_PENDING_TASKS.md` and `07_NEXT_ACTION.md`.
9. Open the latest entry in `08_SESSION_LOG.md`.
10. Open the newest file in `SESSION_DELTAS/`.
11. Use `10_RAW_TRANSCRIPT.md` only when exact wording, exact sequence, or a disputed detail matters.

## If files disagree
- Exact visible history: use `10_RAW_TRANSCRIPT.md`.
- Active rules: use `04_DECISION_LEDGER.md`, `05_CORRECTION_LEDGER.md`, and `03_SECURITY_AND_PRIVACY_RULES.md`.
- Current working status: use the latest dated `SESSION_DELTAS/` file, then `01_CURRENT_STATE.md`.
- Next action: use `07_NEXT_ACTION.md`, but check the latest session delta if it is stale.

## What to rebuild first
If the vault is damaged, recreate these minimum files first:
- `00_READ_ME_FIRST.md`
- `01_CURRENT_STATE.md`
- `03_SECURITY_AND_PRIVACY_RULES.md`
- `04_DECISION_LEDGER.md`
- `05_CORRECTION_LEDGER.md`
- `07_NEXT_ACTION.md`
- latest `SESSION_DELTAS/YYYY-MM-DD-###.md`
- `11_NEXT_CHAT_STARTUP_PROMPT.txt`

## Never overwrite without preserving history
Do not delete older session deltas, old transcripts, or prior outputs. Move obsolete material to `ARCHIVE/` when needed.

## Security restore rule
Never restore actual secret values into the vault. Restore only the secret name, purpose, owner/location, and status, using placeholders such as `[VALUE INTENTIONALLY OMITTED]`.
