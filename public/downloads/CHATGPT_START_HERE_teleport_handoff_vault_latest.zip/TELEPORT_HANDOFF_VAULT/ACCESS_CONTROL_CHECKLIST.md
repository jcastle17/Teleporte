# Access Control Checklist

Use this before storing or sharing the vault.

## GitHub repo
- [ ] Repo is private.
- [ ] No secret values are committed.
- [ ] Collaborators are limited to people/tools intentionally approved.
- [ ] Branch protections are considered if multiple tools can write.
- [ ] `.env`, token files, and secret screenshots are excluded.

## Cloudflare
- [ ] Secrets live in Cloudflare secret fields, not repo files.
- [ ] API tokens are scoped narrowly.
- [ ] Tokens are not pasted into chat or prompt files.
- [ ] Admin/write routes are protected before public use.

## Local/iPad backups
- [ ] ZIP exports are saved in a folder the user can find.
- [ ] Old ZIPs with private info are not shared publicly.
- [ ] Screenshots showing secrets are removed or redacted.

## Sharing with a new chat
- [ ] Upload only what is needed.
- [ ] Confirm no secret values are included.
- [ ] Use the startup prompt.
- [ ] Require the chat to state known blockers and unknowns before acting.
