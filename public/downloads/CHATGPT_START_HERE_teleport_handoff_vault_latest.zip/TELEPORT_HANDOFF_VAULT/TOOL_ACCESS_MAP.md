# Tool Access Map

Purpose: explain what each tool/service is for so future chats do not mix up roles.

## ChatGPT
Used for planning, rewriting, verification, handoff maintenance, prompt design, file creation, and reasoning across the project.

## Gemini / coding assistant
Used for repo inspection, scoped edits, build/test runs, and coding missions. Preferred workflow is one complete mission prompt, not tiny stop-and-go tasks, unless there is a true blocker.

## Copilot
Used similarly to Gemini when quota/access is available.

## GitHub
Used for repositories, version history, remote vault storage, branches, commits, and handoff files.

## Codespaces
Used for editing/running repo commands from iPad. Instructions must be iPad-friendly and not assume desktop keyboard shortcuts.

## Cloudflare Pages
Used to deploy the website/static app and Pages Functions/Worker-style backend when configured.

## Cloudflare D1
Used for structured database records, such as feed items, tracker metadata, and project data when configured.

## Cloudflare R2
Potential storage for large files, images, PDFs, ZIP backups, raw transcript archives, and generated outputs.

## iCloud / Google Drive / local iPad Files
Optional secondary backup locations for ZIP exports and offline copies.

## Password manager / secure secret storage
Used for actual secret values. The vault must only reference where secrets live, not store them.
