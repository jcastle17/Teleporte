# Quality Checklist

Before handing off to the next chat, confirm:

- [ ] Current state was updated.
- [ ] Next action was updated.
- [ ] Pending tasks were updated.
- [ ] Session log entry was added.
- [ ] New session delta was created.
- [ ] New attachments/files were indexed.
- [ ] Unknowns were marked instead of guessed.
- [ ] No secrets, tokens, API keys, passwords, or private keys were stored.
- [ ] The raw transcript was preserved or appended without rewriting when available.
- [ ] The next chat startup prompt is still accurate.


## Screenshot retention checklist

Before exporting the vault:
- Did I avoid saving screenshot image files by default?
- If screenshots mattered, did I add a redacted extract to `SCREENSHOT_EXTRACT_LOG.md`?
- Did I use `SCREENSHOT_EXTRACT_TEMPLATE.md` where helpful?
- Did I redact tokens, private URLs, emails, notifications, account info, and unrelated private details?
- Did I only preserve original screenshot files when the user explicitly requested it?
