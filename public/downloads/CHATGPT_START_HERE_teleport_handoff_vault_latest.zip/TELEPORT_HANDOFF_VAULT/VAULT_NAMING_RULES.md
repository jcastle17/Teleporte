# Vault Naming Rules

Purpose: keep the Teleport Handoff Vault clean, searchable, and easy for future chats to update.

## Core rule
Use predictable names. Do not create random names like `notes-final-new-real2.md`.

## Session deltas
Format:

`SESSION_DELTAS/YYYY-MM-DD_###_short-topic.md`

Example:

`SESSION_DELTAS/2026-05-23_004_maintenance-files-added.md`

## Raw transcripts
Format:

`RAW_TRANSCRIPTS/YYYY-MM-DD_###_chat-topic_RAW_TRANSCRIPT.md`

## Screenshot extracts
Do not save screenshot image files by default. If extracting information from screenshots, add entries to `SCREENSHOT_EXTRACT_LOG.md` or use:

`SCREENSHOT_EXTRACTS/YYYY-MM-DD_###_short-topic.md`

## Preserved attachments
Only preserve original files/screenshots when the user explicitly says to save them.

Format:

`ATTACHMENTS/YYYY-MM-DD_###_short-description.ext`

## Output files
Generated documents, ZIPs, exports, or final artifacts go in `OUTPUTS/`.

Format:

`OUTPUTS/YYYY-MM-DD_###_short-description.ext`

## Avoid
- spaces in filenames
- vague names like `final`, `new`, `copy`, `stuff`, `notes`
- secret values in filenames
- phone numbers, addresses, emails, tokens, API keys, or private identifiers in filenames

## Preferred tags in filenames
Use short topic labels when helpful:

`gemini`, `codespaces`, `cloudflare`, `boxelderanswers`, `security`, `legal`, `screenshot-extract`, `handoff`, `vault`, `next-action`.
