# Raw Transcript Index

Use this file to map sections of the raw transcript.

## Index template

### Section [number]: [topic]
Approximate date/time:
[Date/time]

Transcript location:
[`10_RAW_TRANSCRIPT.md` or file path]

Important details:
- [Detail]

Files/screenshots involved:
- [File]
