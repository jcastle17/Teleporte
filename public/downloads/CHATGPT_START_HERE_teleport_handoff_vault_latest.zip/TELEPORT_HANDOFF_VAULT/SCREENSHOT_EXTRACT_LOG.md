# Screenshot Extract Log

This file stores **text-only extracts** from screenshots so the vault does not need to save every image.

## Policy summary

- Do not save screenshots by default.
- Extract only useful information.
- Redact sensitive/private details.
- Save original screenshot only if user explicitly says to preserve it.
- Future chats should read this log before opening any screenshot files.

## Entries

### 2026-05-23 — Screenshot retention system added

**Session / topic:** Teleport Handoff Vault optimization

**Original screenshot saved?:** No

**What was established:**
- The vault should not archive every screenshot the user sends.
- Screenshots should normally be treated as temporary visual context.
- The vault should save text extracts of what mattered instead of image files.
- Original screenshots should only be saved if the user explicitly requests preservation.

**Sensitive/private information omitted:** N/A

**Next action:**
Future chats should use `SCREENSHOT_EXTRACT_TEMPLATE.md` for screenshot-based updates and follow `SCREENSHOT_RETENTION_POLICY.md`.

---
