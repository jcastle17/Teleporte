# Screenshot Retention Policy

## Purpose

This vault is designed to carry useful memory forward without becoming overloaded by thousands of screenshots.

Screenshots are treated as **temporary visual context** unless the user explicitly says to preserve the original image.

## Default rule

**Do not save screenshot files into the vault by default.**

For every screenshot shown in a chat, save only a short text extract describing what mattered.

## Save the original screenshot only when the user clearly says one of these:

- "save this screenshot"
- "attach this screenshot"
- "preserve this image"
- "keep the original"
- "add the screenshot to the vault"
- "this screenshot is evidence"
- "we may need the original later"

If the user does not say that, do not archive the image file.

## What to extract from a screenshot

For each screenshot, record only the useful information:

- date/time of the chat if known
- what screen/app/site/tool was shown
- the specific visible issue or status
- important error messages
- visible buttons or navigation state needed for next steps
- decisions made because of the screenshot
- next action caused by the screenshot
- whether original screenshot was saved: Yes/No
- reason the original was or was not saved

## What to redact or omit

Do not store sensitive or unnecessary visual details such as:

- API keys, tokens, passwords, private keys, recovery codes, auth headers, secret values
- full private URLs containing session tokens or private query strings
- account numbers, financial details, full addresses, private legal/medical details unless the user specifically needs them preserved
- random tabs, notifications, personal messages, contact info, email inbox contents, or unrelated screen details
- exact screenshots of dashboards that reveal private security details

Use placeholders such as:

`[token visible in screenshot — omitted]`

`[private email visible — omitted unless needed]`

`[Cloudflare secret exists — value not stored]`

## Storage rule

The screenshot extract goes in:

`SCREENSHOT_EXTRACT_LOG.md`

The screenshot file itself goes in:

`ATTACHMENTS/IMAGES/`

only if explicitly preserved.

## Load rule for future chats

Future chats must not load screenshot files by default. They should first read the text extract. Open original screenshots only if the extract is not enough or the user asks for exact visual review.

## Why this matters

This keeps the vault light, safer, easier to search, and less likely to overload ChatGPT, GitHub, Google Drive, iCloud, or Cloudflare storage.

Generated: 2026-05-23
