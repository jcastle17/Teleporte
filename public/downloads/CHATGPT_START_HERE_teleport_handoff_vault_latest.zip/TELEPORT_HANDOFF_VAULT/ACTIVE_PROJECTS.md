# Active Project Override — Latest Checkpoint

The latest official checkpoint makes **Box Elder Answers / T1 Civic Tracker** the current primary project context for the next chat.

Status: live/connected; remaining work is visual review and small polish.
Next action: review `https://t1-a2g.pages.dev/?v=1779561494` and the key public routes before any new coding mission.

---

# Active Projects

Purpose: show what is currently alive so a new chat does not treat old side discussions as active work.

## Active

### Teleport Handoff Vault
Status: active setup/testing.
Current goal: create a remote/lightweight handoff system where future chats can load a vault link or ZIP, read the correct files in order, and continue with low overload.
Next action: upload/store the vault in the chosen private remote location and test it in a fresh chat using Light Load.

### Box Elder Answers / Website Workflow
Status: recurring active project, but not the immediate task unless the user asks about it.
Current context: website/civic tracker/Gemini/Codespaces/Cloudflare workflows may use this vault for continuity.

## Parked / only active when user asks
- legal/custody document workflows
- image generation workflows
- general iPad troubleshooting
- old one-off metadata/QR code questions

## Rule
If the user starts a new chat with this vault and does not name a project, start by orienting around the Teleport Handoff Vault and ask/identify which active project they want to continue.
---

## v1.5 Side Project Note

### Lucky 75 Barber & Salon Parlour Website
Status: separate local-business website project; active only when the user asks.
Context: preserve original Lucky 75 brand feel while upgrading into a polished black/white/grayscale luxury-parlour site with a front-page choice between booking path and story path, plus gallery/reviews/share/story return loop.
Do not mix this project into Box Elder Answers unless the user clearly switches to local-business website work.
