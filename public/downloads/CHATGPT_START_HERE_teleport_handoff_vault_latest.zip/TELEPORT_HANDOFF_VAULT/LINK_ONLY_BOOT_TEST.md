# Link-Only Boot Test

Purpose: test whether the skeleton works when the user pastes only the Cloudflare boot link.

## Test prompt

In a brand-new chat, paste only the boot page link. Do not add any extra instructions.

## Pass condition

The new chat should recognize that the page is an AI handoff boot page and should attempt to load or summarize the vault instructions.

A good first response should include:

1. It recognizes the link is a handoff/boot page.
2. It says it should read the latest vault ZIP.
3. It identifies `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt` as the first file inside the ZIP.
4. It uses Light Load first.
5. It knows not to read raw transcripts/screenshots unless needed.
6. It lists current mission, previous stopping point, workflow rules, security rules, blockers, and next action.

## Partial pass

If the chat says it cannot open links, it should ask the user to upload the ZIP or paste the boot page text. That is acceptable.

## Fail condition

The test fails if the chat:

- treats the link as a random website
- asks "what do you want me to do with this?" even though the page explains it
- reads archives first
- asks for secrets/tokens
- suggests saving raw screenshots by default
- ignores the read order

## Fix if test fails

Make the boot page title and first paragraph stronger:

"CHATGPT: THIS IS AN AI HANDOFF BOOT PAGE. IF THIS LINK WAS PASTED ALONE, LOAD THE VAULT."

Also make the ZIP filename stronger:

`CHATGPT_START_HERE_teleport_handoff_vault_latest.zip`
