# Timeline Master

Purpose: capture the big story in order. This is different from the session log.

## Timeline entries

### 2026-05-23 — Teleport Handoff concept
The user wanted a way for a new chat to read the entire previous conversation, understand exact context down to the periods, and continue as if the prior chat teleported forward.

### 2026-05-23 — Two-layer system chosen
Decision: preserve a raw exact archive while also maintaining current-state working files so the next chat is immediately useful.

### 2026-05-23 — Rolling update system chosen
Decision: every chat should append a session delta, update current state, update next action, and pass the packet forward.

### 2026-05-23 — Remote vault idea
Decision: use a private remote vault, preferably GitHub first for speed/version history, with possible later Cloudflare Worker/D1/R2 engine.

### 2026-05-23 — Deep backup expansion
Added restore instructions, redacted secrets inventory, tool map, file tree, exact prompts, bad-output warnings, checksums, backup locations, human recovery summary, and remote sync planning.
