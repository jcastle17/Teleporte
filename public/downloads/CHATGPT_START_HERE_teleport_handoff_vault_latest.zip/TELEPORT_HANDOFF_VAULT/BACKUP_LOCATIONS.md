# Backup Locations

Purpose: track where backup copies exist without exposing private links or passwords.

## Primary backup
Location type: [Private GitHub repo / other]
Repo/folder name: [Fill in]
Access: [owner only / selected collaborators]
Notes: Do not make public unless intentionally sanitized.

## Secondary backup
Location type: [iCloud Drive / Google Drive / local iPad Files / external drive]
Folder name: [Fill in]
Notes: Keep ZIP copies here.

## Emergency offline backup
Location type: [Downloaded ZIP / external storage]
Date created: [Fill in]
Notes: Useful if remote access breaks.

## Optional future Cloudflare backup
Location type: Cloudflare R2 bucket
Bucket name: [Fill in only if safe]
Notes: Store encrypted/sanitized ZIPs only. Do not store raw secrets.

## Backup rule
Every major session should create a new dated ZIP export and keep at least one prior version.

## Recommended one-link backup layout

Primary live link:
Location type: Cloudflare Pages boot page
Purpose: one pasted URL that explains the vault and links to latest files
Public safety: boot page only; no private vault contents unless sanitized

Primary source:
Location type: Private GitHub repo
Purpose: editable text vault, read order, changelog, templates, release ZIPs
Public safety: private by default

Release asset:
Location type: GitHub Releases
Purpose: latest downloadable ZIP for future chats
Recommended name: `CHATGPT_START_HERE_teleport_handoff_vault_latest.zip`

Secondary backup:
Location type: Google Drive
Purpose: dated ZIP backups, heavy files, emergency copies
Public safety: restricted/private by default
