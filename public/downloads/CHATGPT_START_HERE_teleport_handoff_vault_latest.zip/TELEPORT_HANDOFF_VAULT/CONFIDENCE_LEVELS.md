# Confidence Levels

Purpose: force future chats to label uncertainty instead of guessing.

## Use these labels when reporting status

### Confirmed
Directly supported by current vault files, a visible transcript, a preserved original record, or the user's latest instruction.

### Likely
Supported by surrounding context but not directly proven in the currently opened files.

### Unknown
Not found or not verified.

### Needs user confirmation
Cannot safely proceed without the user choosing or confirming.

### Needs tool/source verification
Could have changed, depends on a live service, or requires checking GitHub/Cloudflare/Drive/calendar/email/web/etc.

## Rule
When in doubt, say what is confirmed, what is likely, and what remains unknown. Do not present guesses as facts.
