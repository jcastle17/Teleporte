# LATEST CHECKPOINT TEMPLATE

Use this for the main teleport chat before moving into a new chat.

Create a plain Markdown file named exactly:

`00_LATEST_CHECKPOINT_READ_FIRST.md`

---

# LATEST CHECKPOINT READ FIRST

## Main Teleport Chat
This checkpoint was prepared from the main teleport chat.

## Date
YYYY-MM-DD

## Project Name
[Project name]

## Purpose of the Project
[What this project is for]

## Where We Are Right Now
[The current live status]

## What Already Exists
- [Existing item]
- [Existing item]

## What Is Not Connected Yet
- [Missing/unconnected item]
- [Missing/unconnected item]

## What Was Just Decided
- [Decision]
- [Decision]

## Files or Logs Considered
- [File/log]
- [File/log]

## Current Official Status
[The cleaned official status]

## Pending Tasks
- [Task]
- [Task]

## Immediate Next Action
[The exact first thing the next chat should do]

## What the Next Chat Should Read First
1. `00_LATEST_CHECKPOINT_READ_FIRST.md`
2. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
3. `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
4. `00_READ_ME_FIRST.md`
5. `01_CURRENT_STATE.md`
6. `06_PENDING_TASKS.md`
7. `07_NEXT_ACTION.md`
8. `04_CHAT_LOG_INBOX/`

## What the Next Chat Should Ignore Unless Needed
- Old archive files
- Raw screenshots
- Long transcripts
- Process history that does not affect the next step

## Security and Privacy Rules
- Do not include or expose secrets, tokens, passwords, API keys, or private values.
- Treat secret locations as references only, never actual values.
- Do not permanently store unnecessary private information.
- Use light-load first. Deep-read only when needed.

## Screenshot and Storage Rules
- Do not save every screenshot.
- Extract useful information from screenshots into notes.
- Keep raw screenshots only when they are necessary evidence or reference material.
- Prefer summarized screenshot digestion over image hoarding.

## Supersession Rule
This checkpoint supersedes older logs unless the older logs are needed for extra detail.
