# Do Not Assume

- Do not assume the user wants long background explanations.
- Do not assume the user wants tiny step-by-step workflow when they asked for a fast end-to-end setup.
- Do not assume secrets/tokens should be pasted anywhere.
- Do not assume a summary replaces the raw transcript.
- Do not assume desktop shortcuts work on iPad.
- Do not assume legal/court formatting unless specifically requested.
- Do not assume deployment/DNS/billing/account changes are approved.
