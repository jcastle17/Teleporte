# One-Link Teleport Setup

## Goal

The user wants to paste one link into a new chat and have the chat understand what to do without needing a separate command.

The best skeleton for that is:

`One Cloudflare boot URL -> boot page instructions -> latest GitHub release ZIP -> vault read order -> current state -> next action`

Google Drive should be backup/private storage, not the main front door, unless the user intentionally chooses the simpler Drive-only setup.

## Recommended live architecture

### 1. Cloudflare Pages: public front door

Cloudflare hosts the human-readable and AI-readable boot page.

Recommended path:

`/teleport`

or

`/ai-handoff-start-here`

This page should contain:

- plain-English AI boot instructions
- the machine-readable JSON bootstrap block
- latest vault ZIP link
- safe manifest link
- backup link placeholder
- limitation note explaining that a link cannot force every chat to auto-open files

### 2. GitHub: source of truth and version history

GitHub stores:

- vault text files
- boot page template
- manifest files
- changelog/session delta files
- release ZIPs

Use a private repo unless the vault has been sanitized for public sharing.

Recommended release asset name:

`CHATGPT_START_HERE_teleport_handoff_vault_latest.zip`

That makes the file purpose obvious even if the page is skipped.

### 3. Google Drive: backup and heavy storage

Google Drive stores:

- dated ZIP backups
- raw screenshot folders if explicitly preserved
- large PDFs/docs/attachments
- emergency copies

Drive links should stay restricted/private by default. Only make a Drive link public if the user understands the exposure risk and intentionally approves it.

## What the pasted link should do

When a future chat receives only the Cloudflare boot page link, it should infer:

1. The link is not a random website.
2. It is an AI handoff boot page.
3. The user wants the vault loaded.
4. The chat should read Light Load first.
5. The chat should report current state, pending tasks, and next action.

## Why not paste the raw ZIP link?

A raw ZIP link gives less context. A future chat may treat it as just a file.

A boot page explains the purpose before the ZIP is opened.

## Why not paste a Google Drive link only?

Google Drive is easy for storage but weaker as the main boot doorway because permissions and sign-in requirements can break access. It is still useful as a backup copy.

## Why not only GitHub?

GitHub alone can work if the chat can access the repo/release link. The issue is that a bare GitHub ZIP or repo link may not clearly tell the future chat what to do. A Cloudflare boot page gives clearer instructions and a cleaner one-link experience.

## Skeleton success test

A brand-new chat should be able to answer these after loading:

1. What is this vault?
2. What file controls the read order?
3. What should be read lightly first?
4. What should not be read unless needed?
5. What is the current state?
6. What is pending?
7. What is the next action?
8. What must never be stored?
9. Where do large files/backups live?
10. Which source wins if files disagree?
