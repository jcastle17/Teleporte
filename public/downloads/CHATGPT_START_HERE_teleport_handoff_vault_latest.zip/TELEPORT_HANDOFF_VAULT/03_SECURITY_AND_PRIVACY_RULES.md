# Security and Privacy Rules

## Never store these in the vault
- API keys
- Tokens
- Passwords
- Private keys
- Secret values
- Recovery codes
- Full access credentials
- Revealing hints that could reconstruct a secret

## Use placeholders instead
Examples:
- `[Cloudflare secret exists; value intentionally omitted]`
- `[Gemini API key exists in secure environment; value intentionally omitted]`
- `[Ingest token exists; value intentionally omitted]`

## Before writing prompts for external tools
Do not paste secrets into ChatGPT, Gemini, Copilot, public repos, README files, screenshots, terminal history, or handoff files.

## Remote storage rule
The vault should be private by default unless the user intentionally chooses otherwise.

## Sensitive personal/legal material
If legal, custody, private family, private identifying, or sensitive material is included, keep it controlled and do not expose it to public repos or public links.
