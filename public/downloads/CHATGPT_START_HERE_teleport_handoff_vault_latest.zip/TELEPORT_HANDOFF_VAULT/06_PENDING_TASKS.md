# Pending Tasks — From Latest Official Checkpoint

## Immediate visual review
- [ ] Open `https://t1-a2g.pages.dev/?v=1779561494` and visually review the cleaned homepage.
- [ ] Confirm whether public cards are clean, readable, and not overflowing.
- [ ] Review `https://t1-a2g.pages.dev/feed`.
- [ ] Review `https://t1-a2g.pages.dev/stratos`.
- [ ] Review `https://t1-a2g.pages.dev/water`.
- [ ] Review `https://t1-a2g.pages.dev/power`.
- [ ] Review `https://t1-a2g.pages.dev/community`.
- [ ] Review `https://t1-a2g.pages.dev/records`.
- [ ] Review `https://t1-a2g.pages.dev/admin`.

## Small polish only if needed
- [ ] If the Park Record generic source label still appears, apply only a tiny publisher-extraction refinement.
- [ ] Decide whether to keep, remove, or demote weak/background items that feel off-mission.
- [ ] Decide whether to finalize launch on the current Pages URL or proceed to custom domain routing.
- [ ] Decide whether to add automated scheduled ingest/cron after visual launch review.

## Later guardrails if desired
- [ ] Add GitHub Actions/smoke tests/Playwright visual checks/Sentry/Checkly/Oh Dear if the user wants deeper monitoring.
- [ ] Keep Better Stack monitors under the free-plan limit unless intentionally upgrading.

## Completed vault task
- [x] Installed official `00_LATEST_CHECKPOINT_READ_FIRST.md` from the main teleport chat.

---

# Pending Tasks

## Active tasks
- [ ] [Task]

## Blocked tasks
- [ ] [Task] — blocked by [reason]

## Waiting on user
- [ ] [Task]

## Done recently
- [x] Created vault template

## Pending — one-link boot system

- Fill actual Cloudflare boot page URL once created.
- Fill actual GitHub repository/release ZIP URL once created.
- Fill Google Drive backup location only if safe and intentional.
- Run `LINK_ONLY_BOOT_TEST.md` in a brand-new chat after the boot page is live.
- Decide whether the vault will use a two-vault model: public loader vault + private working vault.

## Pending — chat log inbox chain installed 2026-05-23

- [ ] Receive the official `00_LATEST_CHECKPOINT_READ_FIRST.md` from the main teleport chat and replace the placeholder.
- [ ] Receive any remaining side-chat `.md` logs and place them in `04_CHAT_LOG_INBOX/`.
- [ ] Review `04_CHAT_LOG_INBOX/chat-log-gemini-coding-workflow-3-2026-05-23.md`.
- [ ] Because that Gemini Workflow 3 log says no project work occurred yet, do not update `01_CURRENT_STATE.md` with coding/deployment claims from it.
- [ ] Use the Gemini Workflow 3 log only to confirm that the next chat should wait for and follow the formal handoff instead of guessing from the chat title.
---

# v1.5 Pending Intake Review

- [ ] Review the four newly installed `04_CHAT_LOG_INBOX/` entries before preparing a new official checkpoint.
- [ ] Decide whether the D1/cloud activation and RSS/build-history logs should be treated as historical context only or merged into the next checkpoint.
- [ ] Keep `00_LATEST_CHECKPOINT_READ_FIRST.md` as current truth unless the user asks to generate a newer checkpoint.
- [ ] Keep the Lucky 75 local-business website work separate from Box Elder Answers unless the user explicitly switches projects.
