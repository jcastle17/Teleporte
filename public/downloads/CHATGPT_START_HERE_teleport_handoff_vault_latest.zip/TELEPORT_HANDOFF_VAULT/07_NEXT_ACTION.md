# Next Action — From Latest Official Checkpoint

The next chat should start with visual review, not another rebuild.

1. Open the fresh homepage:
   `https://t1-a2g.pages.dev/?v=1779561494`
2. If it looks clean, check:
   - `https://t1-a2g.pages.dev/feed`
   - `https://t1-a2g.pages.dev/stratos`
   - `https://t1-a2g.pages.dev/water`
   - `https://t1-a2g.pages.dev/power`
   - `https://t1-a2g.pages.dev/community`
   - `https://t1-a2g.pages.dev/records`
   - `https://t1-a2g.pages.dev/admin`
3. Only prepare a small targeted Gemini/Copilot mission if a visible issue remains.
4. Do not start another large rebuild unless visual review shows a broad structural problem.

---

# Next Action

When opening this vault in a new chat, upload the ZIP and paste the contents of:

`NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt`

Or tell the chat:

"Open !!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt first and follow the boot sequence."

The next chat should then read the vault in order, identify the current mission, where the last chat left off, active workflow rules, active security rules, known blockers, and the next safest action before giving steps.

## Updated next action rule
When opening this vault in a new chat, use Light Load by default. Open the bootloader/read-order/current-state/security/access/sensitive-filter/conflict/load-mode files first. Only deep-dig raw transcripts or attachments when exact old context is needed.


## Updated next action — 2026-05-23
Upload/store the updated vault in a private remote location. Prefer an unzipped private GitHub repo for text brain files and Drive/iCloud/R2 for heavy media. Then open a brand-new chat and run the test in `TEST_STARTUP_SCRIPT.md` using Light Load only.

## Next action — skeleton phase

Create or publish the Cloudflare boot page using `AI_BOOT_PAGE_HTML_TEMPLATE.html`, then link it to the latest vault ZIP release. Do not connect databases yet. First prove that one pasted link can guide a new chat through Light Load.

## Next action — after installing Gemini Workflow 3 inbox log 2026-05-23

The next required action is to receive the real main teleport checkpoint file named:

`00_LATEST_CHECKPOINT_READ_FIRST.md`

The installed inbox log `04_CHAT_LOG_INBOX/chat-log-gemini-coding-workflow-3-2026-05-23.md` is clean and safe, but it does not contain completed coding/deployment work. It mainly tells the next chat not to assume the mission from the phrase “Gemini Coding Workflow 3” and to wait for the formal handoff.
---

# v1.5 Added Context Before the Next Handoff

Before a future chat launches a new coding/design mission, it should quickly check `04_CHAT_LOG_INBOX/README.md` and the four v1.5 inbox logs to see whether the user wants those side-chat details merged into a newer checkpoint.

Default behavior remains:

1. Read `00_LATEST_CHECKPOINT_READ_FIRST.md`.
2. Treat that as the official current truth.
3. Review the new inbox logs only when the user asks for deeper context or when creating the next checkpoint.
