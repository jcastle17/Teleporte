# Prompt Library

## Next chat startup prompt
See `11_NEXT_CHAT_STARTUP_PROMPT.txt`.

## End-of-chat update prompt
Update the Teleport Handoff Vault for the next chat.

Create one new session delta in `SESSION_DELTAS/` and update:
- `01_CURRENT_STATE.md`
- `06_PENDING_TASKS.md`
- `07_NEXT_ACTION.md`
- `08_SESSION_LOG.md`
- `09_RAW_TRANSCRIPT_INDEX.md` if needed
- `ATTACHMENT_INDEX.md` if files/screenshots were added

Do not store secrets, tokens, passwords, private keys, API keys, or hidden values.
Mark unknowns clearly instead of guessing.

## Coding assistant mission prompt template
Read the handoff vault files first. Continue from the current state. Make only scoped changes necessary for the mission. Do not expose secrets. Stop before secrets/tokens, billing, DNS/domain changes, Cloudflare dashboard-only changes, destructive commands, force push, unresolved merge conflicts, or ambiguous major design decisions. When done, update the handoff files and report what changed.
