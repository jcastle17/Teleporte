# TELEPORT HANDOFF VAULT — START HERE

This ZIP has been upgraded with a bootloader-style read protocol.

## Important reality check

A ZIP file cannot force ChatGPT to automatically run code or automatically read every file without being prompted. What this packet can do is make the required read order, first response, and end-of-chat save protocol impossible to miss.

The controlling boot files are:

1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `AI_BOOTSTRAP.json`
3. `00_BOOT_SEQUENCE_FOR_NEXT_CHATGPT.md`
4. `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
5. `NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt`
6. `END_OF_CHAT_SAVE_PROTOCOL.md`

## Required read order

1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `AI_BOOTSTRAP.json`
3. `00_READ_ME_FIRST.md`
4. `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
5. `01_CURRENT_STATE.md`
6. `02_USER_STYLE_AND_RESPONSE_RULES.md`
7. `03_SECURITY_AND_PRIVACY_RULES.md`
8. `SOURCE_OF_TRUTH.md`
9. `04_DECISION_LEDGER.md`
10. `05_CORRECTION_LEDGER.md`
11. `KNOWN_UNKNOWNS.md`
12. `06_PENDING_TASKS.md`
13. `07_NEXT_ACTION.md`
14. Latest entry in `08_SESSION_LOG.md`
15. Latest file in `SESSION_DELTAS/`
16. Use `10_RAW_TRANSCRIPT.md` or `RAW_TRANSCRIPTS/` only when exact wording or deeper history is needed.

## Required first response

After loading, the next chat must identify:

1. Current mission
2. Where the previous chat left off
3. Active workflow rules
4. Active security rules
5. Known blockers / unknowns
6. Next safest action

Then it should wait for the user's instruction.

---


# Teleport Handoff Vault — Read Me First

This folder is the portable memory system for continuing a project across chats.

## Read order for a new chat

1. `00_READ_ME_FIRST.md`
2. `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
3. `01_CURRENT_STATE.md`
4. `02_USER_STYLE_AND_RESPONSE_RULES.md`
5. `03_SECURITY_AND_PRIVACY_RULES.md`
6. `SOURCE_OF_TRUTH.md`
7. `04_DECISION_LEDGER.md`
8. `05_CORRECTION_LEDGER.md`
9. `06_PENDING_TASKS.md`
10. `07_NEXT_ACTION.md`
11. Latest entry in `08_SESSION_LOG.md`
12. Latest file in `SESSION_DELTAS/`
13. Use `10_RAW_TRANSCRIPT.md` or `RAW_TRANSCRIPTS/` only when exact wording or deeper history is needed.

## Core rule

Do not treat this as a loose summary. Treat it as the active continuation memory of the previous chat.

## End-of-chat update rule

Before passing to the next chat, update:

- `01_CURRENT_STATE.md`
- `06_PENDING_TASKS.md`
- `07_NEXT_ACTION.md`
- `08_SESSION_LOG.md`
- Add one new file to `SESSION_DELTAS/`
- Append exact conversation text to `10_RAW_TRANSCRIPT.md` when available
- Add/describe any new files in `ATTACHMENT_INDEX.md`

Never store actual API keys, tokens, passwords, secret values, private keys, or revealing hints in this vault.

## Deep backup note
This version includes deeper backup/recovery files. Start with the core files first, then use the deep backup files when restoring, auditing, syncing to remote storage, or checking security.


## Screenshot storage rule

Screenshots are not saved by default. They are temporary visual aids. Future chats must save only a redacted text extract in `SCREENSHOT_EXTRACT_LOG.md` unless the user explicitly requests that the original screenshot be preserved.

## Control Expansion Added

The vault now includes extra control files for access permissions, prompt-injection protection, retention levels, sensitive-info filtering, light/deep load modes, evidence vs working memory, conflict resolution, size budgeting, and end-of-chat checklist. Follow `000_MASTER_READ_ORDER_DO_NOT_SKIP.md` for the authoritative read order.

IMPORTANT LATEST CHECKPOINT RULE:
If `00_LATEST_CHECKPOINT_READ_FIRST.md` exists, read it before all other status files. It is the latest official checkpoint from the main teleport chat and may supersede older logs or placeholders.
