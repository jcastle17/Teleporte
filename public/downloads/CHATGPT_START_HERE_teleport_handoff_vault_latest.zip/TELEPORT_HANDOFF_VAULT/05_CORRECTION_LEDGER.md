# Correction Ledger

Record mistakes, frustrations, and corrections so the next chat does not repeat them.

## Correction template

### Correction: [Title]
Date: [YYYY-MM-DD]

Problem:
[What went wrong]

Correction:
[What to do instead]

Why it matters:
[Why this matters to the user/project]

Status:
Active / Replaced / Deprecated
