# Maintenance / Search / Archive Expansion Additions

- `VAULT_NAMING_RULES.md` — naming standards for session deltas, transcripts, extracts, attachments, and outputs.
- `TAGGING_SYSTEM.md` — recommended tags for faster search and filtering.
- `SEARCH_GUIDE_FOR_NEXT_CHAT.md` — search path for finding information without reading the whole archive.
- `MONTHLY_ARCHIVE_PLAN.md` — plan for keeping the vault light over time.
- `PROJECTS_INDEX.md` — broad map of all major project areas.
- `ACTIVE_PROJECTS.md` — what is currently alive versus parked.
- `DO_NOT_CARRY_FORWARD.md` — prevents temporary or failed chat content from becoming permanent instructions.
- `CONFIDENCE_LEVELS.md` — labels for confirmed, likely, unknown, needs confirmation, and needs verification.
- `REMOTE_SYNC_RULES.md` — rules for syncing GitHub/Drive/iCloud/R2 without exposing private data.
- `TEST_STARTUP_SCRIPT.md` — test script to verify a new chat can load the vault in Light Load mode.

---

# Control / Safety / Load-Mode Additions

- `VAULT_ACCESS_AND_PERMISSIONS.md` — keeps vault private by default and controls sharing/link permissions.
- `PROMPT_INJECTION_PROTECTION.md` — prevents old transcripts, screenshots, files, PDFs, or webpages from acting like active instructions.
- `RETENTION_LEVELS.md` — Level 0/1/2/3 save rules for no-save, extract-only, redacted copy, and original preserved.
- `SENSITIVE_INFO_FILTER.md` — rules for redacting secrets, tokens, private account info, legal/private details, and dashboard clutter.
- `LIGHT_MODE_DEEP_MODE_RULES.md` — tells future chats when to use light, medium, deep, or full archive loading.
- `EVIDENCE_VS_WORKING_MEMORY.md` — separates informal AI working notes from original evidence/records.
- `CONFLICT_RESOLUTION_RULES.md` — tells future chats what wins when vault files disagree.
- `VAULT_SIZE_BUDGET.md` — keeps GitHub mostly text and moves heavy attachments to Drive/iCloud/R2.
- `END_OF_CHAT_CHECKLIST.md` — required checklist before passing the vault forward.
- `HUMAN_QUICK_START.md` — plain-English user guide for starting a new chat, using light mode, deep digging, and ending a chat.

---

# Screenshot Extraction / Retention Additions

- `SCREENSHOT_RETENTION_POLICY.md` — policy for not saving screenshots by default.
- `DO_NOT_SAVE_SCREENSHOTS_BY_DEFAULT.md` — hard default rule and trigger phrases for preserving originals.
- `SCREENSHOT_EXTRACT_TEMPLATE.md` — template for text-only screenshot extracts.
- `SCREENSHOT_EXTRACT_LOG.md` — running log of redacted screenshot extracts.

# Read Order Lock Additions

- `000_MASTER_READ_ORDER_DO_NOT_SKIP.md` — master human-readable read order; the next chat should follow this every time.
- `000_READ_ORDER_LOCK.json` — machine-readable read-order lock and fallback load instructions.


# Bootloader Additions

- `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt` — first file a new chat should open; contains mandatory read order and first-response protocol.
- `AI_BOOTSTRAP.json` — machine-readable packet instructions, read order, security rules, and save protocol.
- `00_BOOT_SEQUENCE_FOR_NEXT_CHATGPT.md` — plain-English boot sequence for the next AI.
- `NEXT_CHAT_STARTUP_PROMPT_COPY_THIS.txt` — exact startup prompt the user can paste into a new chat.
- `END_OF_CHAT_SAVE_PROTOCOL.md` — exact update rules before exporting/passing the vault forward.

---

# Manifest

## Core files
- `00_READ_ME_FIRST.md` — read order and rules for using the vault
- `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md` — exact instructions for the next AI/chat
- `01_CURRENT_STATE.md` — current working memory
- `02_USER_STYLE_AND_RESPONSE_RULES.md` — response style and workflow preferences
- `03_SECURITY_AND_PRIVACY_RULES.md` — rules to protect secrets and private data
- `SOURCE_OF_TRUTH.md` — conflict-resolution order
- `04_DECISION_LEDGER.md` — settled decisions
- `05_CORRECTION_LEDGER.md` — mistakes/corrections to avoid repeating
- `06_PENDING_TASKS.md` — active, blocked, waiting, and completed tasks
- `07_NEXT_ACTION.md` — next safe step
- `08_SESSION_LOG.md` — chronological session record
- `09_RAW_TRANSCRIPT_INDEX.md` — map for raw transcript sections
- `10_RAW_TRANSCRIPT.md` — exact visible transcript archive
- `11_NEXT_CHAT_STARTUP_PROMPT.txt` — prompt to paste into the next chat

## Folders
- `SESSION_DELTAS/` — one update file per chat/session
- `RAW_TRANSCRIPTS/` — larger transcript files if separated by session
- `ATTACHMENTS/` — images, PDFs, docs, screenshots
- `OUTPUTS/` — generated ZIPs, Word docs, exports, etc.
- `ARCHIVE/` — deprecated or old packet versions

## Deep Backup Expansion Files
- `RESTORE_INSTRUCTIONS.md` — emergency restore and rebuild instructions.
- `REDACTED_SECRETS_INVENTORY.md` — records secret names/locations/purposes without values.
- `TOOL_ACCESS_MAP.md` — explains which tools/services do what.
- `PROJECT_FILE_TREE.md` — expected folder/file structure snapshot.
- `EXACT_PROMPTS_USED.md` — reusable working prompts.
- `BAD_PROMPTS_AND_BAD_OUTPUTS.md` — failure patterns to avoid.
- `CHECKSUMS_AND_FILE_HASHES.md` — file integrity fingerprints.
- `BACKUP_LOCATIONS.md` — primary/secondary/emergency backup locations.
- `TIMELINE_MASTER.md` — big-picture project timeline.
- `RECOVERY_SUMMARY_FOR_HUMAN.md` — plain-English usage/recovery guide.
- `VERSION_HISTORY.md` — vault structure version log.
- `REMOTE_SYNC_PLAN.md` — future GitHub/Cloudflare/MCP sync roadmap.
- `ACCESS_CONTROL_CHECKLIST.md` — safety checklist before sharing/storing.
- `EXPORT_AND_IMPORT_INSTRUCTIONS.md` — how to move the vault between chats/tools.
- `PACKET_AUDIT_LOG.md` — records structural changes to the packet.

## One-Link Remote Architecture Additions

- `AI_LINK_ONLY_BOOT_PAGE.md` — exact text for the Cloudflare boot page so a future chat understands a pasted link by itself.
- `AI_BOOT_PAGE_HTML_TEMPLATE.html` — ready-to-adapt HTML template for the Cloudflare boot page.
- `ONE_LINK_TELEPORT_SETUP.md` — explains the one-link flow from Cloudflare to GitHub ZIP to vault read order.
- `REMOTE_ARCHITECTURE_RECOMMENDATION.md` — explains the recommended Cloudflare/GitHub/Google Drive roles.
- `SIMPLER_METHODS_COMPARISON.md` — compares easier alternatives to the three-service setup.
- `PUBLIC_PRIVATE_SPLIT_RULES.md` — prevents private vault content from being published accidentally.
- `LINK_ONLY_BOOT_TEST.md` — pass/fail test for whether one pasted link is enough.

## Chat log inbox / checkpoint additions — 2026-05-23

- `00_LATEST_CHECKPOINT_READ_FIRST.md` — first file a future chat should read if present. Currently installed as a placeholder until the main teleport checkpoint is provided.
- `04_CHAT_LOG_INBOX/` — folder for side-chat/helper-chat Markdown log entries before they are merged into official vault status.
- `04_CHAT_LOG_INBOX/chat-log-gemini-coding-workflow-3-2026-05-23.md` — installed inbox log confirming that Gemini Coding Workflow 3 has not performed project work yet and is waiting for formal handoff instructions.
- `05_PROCESSED_CHAT_LOGS/` — folder for reviewed/processed chat logs.
- `CHAT_LOG_ENTRY_TEMPLATE.md` — clean Markdown template for side chats.
- `LATEST_CHECKPOINT_TEMPLATE.md` — clean Markdown template for the main teleport chat checkpoint.


## Official latest checkpoint installed — 2026-05-23

- `00_LATEST_CHECKPOINT_READ_FIRST.md` — now contains the official main teleport checkpoint for Box Elder Answers / T1 Civic Tracker. This supersedes the previous placeholder.
- `SESSION_DELTAS/2026-05-23_008_official-latest-checkpoint-installed.md` — records this installation event.
- `01_CURRENT_STATE.md`, `06_PENDING_TASKS.md`, `07_NEXT_ACTION.md`, `ACTIVE_PROJECTS.md`, `AI_BOOTSTRAP.json`, and `000_READ_ORDER_LOCK.json` were updated to point the next chat to the checkpoint and immediate visual-review step.
---

# v1.5 — Additional Chat Log Inbox Entries Installed

Installed in `04_CHAT_LOG_INBOX/`:

- `chat-log-gemini-copilot-cloudflare-d1-activation-2026-05-23.md`
- `chat-log-website-improvement-suggestions-2026-05-23.md`
- `chat-log-website-redesign-reference-pass-2026-05-23.md`
- `chat-log-building-local-business-websites-2026-05-23.md`

Purpose: preserve side-chat context for later checkpoint merging without letting side chats overwrite the official state directly.
