# Recovery Summary for Human

This is the plain-English guide.

## What this vault is
This vault is a portable memory packet. It helps a new chat continue from the last chat without starting over.

## What matters most
The most important files are:
- `00_READ_ME_FIRST.md`
- `LOAD_INSTRUCTIONS_FOR_NEXT_AI.md`
- `01_CURRENT_STATE.md`
- `03_SECURITY_AND_PRIVACY_RULES.md`
- `04_DECISION_LEDGER.md`
- `05_CORRECTION_LEDGER.md`
- `07_NEXT_ACTION.md`
- `08_SESSION_LOG.md`
- latest file in `SESSION_DELTAS/`
- `10_RAW_TRANSCRIPT.md` when exact wording matters

## How to use it in a new chat
1. Upload the vault ZIP or the main files.
2. Paste `11_NEXT_CHAT_STARTUP_PROMPT.txt`.
3. Make the chat summarize mission, status, rules, blockers, and next action.
4. Continue work.
5. At the end, ask the chat to update the vault and make a new ZIP.

## What not to put in it
Do not store actual passwords, API keys, tokens, secret values, private keys, or recovery codes.

## Best mental model
Raw transcript = full memory backup.
Current state = fast save file.
Decision ledger = what stays decided.
Correction ledger = mistakes not to repeat.
Session delta = what this chat added.
Next action = where the next chat starts.
