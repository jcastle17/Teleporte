# Evidence vs Working Memory

## Purpose
This file separates informal project memory from official evidence or records.

## Core rule
The Teleport Handoff Vault is a working-memory system. It helps future chats continue the project.

It is not, by itself, the official evidence archive.

## Working memory examples
Save these as text notes or session deltas:

- what the screenshot showed that mattered
- what step was completed
- what blocker was found
- what prompt worked
- what rule was added
- what the next chat should do

## Evidence examples
Preserve originals separately when user says they are evidence, proof, court-related, or important originals:

- original screenshots of messages
- court/legal documents
- signed forms
- official notices
- timestamped records
- medical/incident communications
- billing/payment records
- exported raw files

## Legal/custody caution
For custody, child support, legal strategy, or court-related materials:

- do not rely only on AI summaries
- preserve originals separately when needed
- keep AI notes clearly separate from original evidence
- do not alter original evidence files
- mark unknowns instead of guessing

## Vault note format for evidence
When an original exists outside the vault, record:

- what it is
- where it is stored
- why it matters
- whether the original is preserved
- whether the vault contains only an extract or a copy

Do not store sensitive original evidence in a public repo.
