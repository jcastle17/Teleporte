# Light Mode / Deep Mode Rules

## Purpose
This file prevents the next chat from overloading itself by reading everything at once.

## Default mode: Light Load
Use Light Load unless the user asks for exact history, old screenshots, or deep transcript search.

Read only:

1. `!!!_OPEN_THIS_FIRST_FOR_CHATGPT.txt`
2. `000_MASTER_READ_ORDER_DO_NOT_SKIP.md`
3. `AI_BOOTSTRAP.json`
4. `01_CURRENT_STATE.md`
5. `02_USER_STYLE_AND_RESPONSE_RULES.md`
6. `03_SECURITY_AND_PRIVACY_RULES.md`
7. `VAULT_ACCESS_AND_PERMISSIONS.md`
8. `SENSITIVE_INFO_FILTER.md`
9. `LIGHT_MODE_DEEP_MODE_RULES.md`
10. `SOURCE_OF_TRUTH.md`
11. `CONFLICT_RESOLUTION_RULES.md`
12. `06_PENDING_TASKS.md`
13. `07_NEXT_ACTION.md`
14. latest `SESSION_DELTAS/` file
15. latest relevant `SCREENSHOT_EXTRACT_LOG.md` entry if screenshots affected the current work

## Medium Load
Use Medium Load when the current state is unclear or the task touches prior decisions.

Also read:

- `04_DECISION_LEDGER.md`
- `05_CORRECTION_LEDGER.md`
- `KNOWN_UNKNOWNS.md`
- `08_SESSION_LOG.md`
- `PROMPT_LIBRARY.md`
- `FAILURE_PATTERNS.md`
- `DO_NOT_ASSUME.md`

## Deep Mode
Use Deep Mode when the user asks to dig, verify, recover, or find exact prior context.

Also search/read:

- `09_RAW_TRANSCRIPT_INDEX.md`
- relevant files in `RAW_TRANSCRIPTS/`
- relevant part of `10_RAW_TRANSCRIPT.md`
- `ATTACHMENT_INDEX.md`
- `SCREENSHOT_EXTRACT_LOG.md`
- older session deltas

## Full Archive Mode
Use Full Archive Mode only when the user explicitly asks to read or rebuild everything.

This may be heavy and should be used only when necessary.

## User commands
If the user says:

- "teleport light" — use Light Load.
- "deep dig" — use Deep Mode for the relevant topic.
- "find the exact wording" — use Deep Mode and raw transcripts.
- "full restore" — use Full Archive Mode.

## Memory rule
A link to the vault is light. Opening files uses context. Raw transcripts and attachments are the heaviest. Do not read them unless needed.
