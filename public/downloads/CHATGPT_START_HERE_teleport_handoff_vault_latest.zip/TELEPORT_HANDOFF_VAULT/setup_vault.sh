#!/usr/bin/env bash
set -euo pipefail

mkdir -p SESSION_DELTAS RAW_TRANSCRIPTS ATTACHMENTS/IMAGES ATTACHMENTS/PDFS ATTACHMENTS/DOCS OUTPUTS ARCHIVE

echo "Teleport Handoff Vault folders are ready. Add template files or unzip the template package into this repo."
