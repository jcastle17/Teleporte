# Export and Import Instructions

## Export at the end of a chat
1. Update `01_CURRENT_STATE.md`.
2. Append a new entry to `08_SESSION_LOG.md`.
3. Create a new file in `SESSION_DELTAS/`.
4. Update `06_PENDING_TASKS.md` and `07_NEXT_ACTION.md`.
5. Update `KNOWN_UNKNOWNS.md` if anything is unclear.
6. Update `ATTACHMENT_INDEX.md` if any files/images/docs were used.
7. Regenerate `CHECKSUMS_AND_FILE_HASHES.md` if possible.
8. Create a dated ZIP export.

## Import into a new chat
1. Upload the ZIP or main vault files.
2. Paste `11_NEXT_CHAT_STARTUP_PROMPT.txt`.
3. Tell the chat not to give steps until it reads the required files.
4. Make the chat identify mission, status, rules, blockers, and next action.
5. Continue work.

## Import into GitHub
1. Create or open the private vault repo.
2. Upload this folder structure.
3. Commit with a clear message such as `Add deep backup vault template`.
4. For later sessions, commit updates with date/session references.

## Import into Cloudflare later
Use only after the GitHub/manual process works. Do not build automation until the vault structure is stable.
