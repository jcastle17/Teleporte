# Known Unknowns

Record things that are not confirmed yet.

## Current unknowns
- [ ] Whether the vault is stored in GitHub, Cloudflare, Drive, iCloud, or another remote storage.
- [ ] Whether raw transcript export will be manual or generated from official ChatGPT export.
- [ ] Whether an automation/API engine will be built later.
